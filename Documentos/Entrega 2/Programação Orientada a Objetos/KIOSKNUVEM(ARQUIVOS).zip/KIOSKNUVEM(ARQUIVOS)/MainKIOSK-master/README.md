# Kiosk - Plataforma B2B para o Mercado de Alimentação e Bebidas 🛒🌱

O **Kiosk** é um marketplace B2B completo e moderno, voltado para conectar produtores rurais, distribuidores e lojistas (donos de mercados, empórios e restaurantes). A plataforma facilita a negociação direta, a compra por atacado e a gestão de produtos com uma interface amigável e otimizada para todos os dispositivos.

---

## Principais Funcionalidades

### Perfis de Usuário
O Kiosk suporta três tipos de usuários:
1. **Lojista/Comprador**: Explora anúncios, avalia fornecedores, adiciona produtos aos favoritos e realiza pedidos.
2. **Fornecedor**: Publica anúncios, define estoques e pedidos mínimos, e acompanha vendas e interações.
3. **Administrador**: Gerencia a plataforma, modera anúncios/avaliações/usuários, analisa relatórios de desempenho e responde a denúncias.

### Marketplace Dinâmico
- **Vitrine Otimizada**: Exibição de produtos por categorias com busca inteligente, filtros e destaque para anúncios recentes.
- **Anúncios Detalhados**: Suporte para até 5 fotos em nuvem, controle de unidade de medida, pedido mínimo e estoque.
- **Sistema de Interações**: Lojistas podem favoritar produtos e dar notas/avaliações públicas aos fornecedores.

### Comunicação e Negociação
- **Chat Integrado**: Sistema de mensagens em tempo real para comprador e fornecedor tirarem dúvidas e fecharem o negócio antes do pedido oficial.

### Segurança e Moderação
- **Denúncias de Anúncios**: Lojistas podem reportar produtos por fraude, informação falsa ou conteúdo ilegal, gerando uma notificação imediata para a moderação.
- **Painel de Moderação**: O administrador pode reprovar anúncios suspeitos, excluir avaliações impróprias ou banir permanentemente fornecedores problemáticos.

### Dashboards e Gamificação
- **Estatísticas em Tempo Real**: Fornecedores têm acesso a gráficos com visualizações, cliques e vendas.
- **Gamificação com Selos**: Fornecedores e Lojistas conquistam selos automáticos de acordo com o nível de atividade (Ex: *Top Fornecedor*, *Comprador Frequente*), ajudando a criar confiança na rede.

---

## Tecnologias Utilizadas

O projeto utiliza uma arquitetura robusta dividida em Backend (API Rest) e Frontend estático.

- **Backend**:
  - [Node.js](https://nodejs.org/) & [Express](https://expressjs.com/)
  - [PostgreSQL](https://www.postgresql.org/) (via [Neon DB](https://neon.tech/)) hospedado na nuvem.
  - Segurança com JWT (JSON Web Tokens) e bcrypt.
  - Upload de imagens diretamente via API integrada.

- **Frontend**:
  - HTML5 Semântico.
  - CSS3 puro com variáveis nativas e Flexbox/Grid (sem frameworks, para máxima performance e personalização).
  - Vanilla JavaScript para integração ágil via `fetch()`.
  - Design Responsivo *Mobile-First*.

---

## Instalação e Execução (Ambiente Local)

Siga os passos abaixo para rodar o Kiosk na sua máquina:

### 1. Preparação do Banco de Dados
A aplicação já aponta para um banco em nuvem Neon DB configurado. No entanto, se precisar recriar localmente:
- Importe as tabelas e regras utilizando as queries presentes na pasta `backend/scratch/` ou as instruções nos arquivos do backend.

### 2. Configurando o Backend (Servidor)
Abra um terminal, vá até a pasta raiz e entre no diretório `backend`:
```bash
cd backend
```
Instale todas as dependências:
```bash
npm install
```
Configure o arquivo `.env`. Na pasta `backend`, crie um arquivo chamado `.env` e insira as seguintes credenciais:
```env
DATABASE_URL=postgresql://neondb_owner:npg_Chkuqw3SobN1@ep-morning-dew-ac3p1amg-pooler.sa-east-1.aws.neon.tech/neondb?sslmode=require&channel_binding=require
JWT_SECRET=sua_chave_
```
Para iniciar o servidor:
```bash
npm start
```
*A API estará escutando as requisições na porta **3000**.*

### 3. Acessando o Frontend
Como o frontend não utiliza frameworks que exigem "build", ele pode ser rodado de forma muito simples:
1. Abra a pasta `frontend/`.
2. Dê duplo clique no arquivo `vitrine.html` ou `login.html`.
3. *(Opcional, mas recomendado)* Utilize a extensão **Live Server** (do VS Code) na pasta `frontend` para ter *hot-reload*.

---

## 🚀 Entrega 2: Integração com API e CRUD Funcional

O sistema agora cumpre integralmente os requisitos de persistência e manipulação de dados via API:

### ⚙️ Configuração da API
- **Base URL Configurável**: Centralizada no arquivo [config.js](file:///c:/Users/davib/Downloads/kiosk-Kiosk-katy/kiosk-Kiosk-katy/frontend/js/config.js). Para mudar o servidor, basta alterar a constante `API_URL`.
- **Serviço de API**: Toda a lógica de comunicação (`fetch`) foi movida para o [api-service.js](file:///c:/Users/davib/Downloads/kiosk-Kiosk-katy/kiosk-Kiosk-katy/frontend/js/api-service.js), seguindo o padrão de responsabilidade única.

### 🛠️ Fluxo CRUD (Exemplo: Gestão de Anúncios)
- **Create (Criar)**: Implementado em [criar_anuncio.html](file:///c:/Users/davib/Downloads/kiosk-Kiosk-katy/kiosk-Kiosk-katy/frontend/criar_anuncio.html). Inclui validações de campos obrigatórios e feedback visual.
- **Read All (Listagem)**: Implementado em [meus-produtos.html](file:///c:/Users/davib/Downloads/kiosk-Kiosk-katy/kiosk-Kiosk-katy/frontend/meus-produtos.html). Busca dados automaticamente ao carregar a página.
- **Read One (Carregamento)**: Implementado em [editar_anuncio.html](file:///c:/Users/davib/Downloads/kiosk-Kiosk-katy/kiosk-Kiosk-katy/frontend/editar_anuncio.html), que busca os dados do item via ID e preenche o formulário automaticamente.
- **Update (Editar)**: Implementado via método `PUT` na página de edição.
- **Delete (Remover)**: Implementado com botão de exclusão, confirmação (`confirm`) e mensagem de sucesso em tempo real.

### 🚥 Estados de UI
- **Loading**: Overlay de "Carregando..." exibido durante todas as operações assíncronas.
- **Sucesso/Erro**: Mensagens coloridas (Toast/Alert) exibidas após cada operação para feedback do usuário.

---

## 📖 Como Usar e Rodar

### 1. Configuração da API
Se o seu backend estiver rodando em uma porta diferente de `3000`, altere o arquivo:
`frontend/js/config.js` -> `API_URL: "http://seu-endereco:porta/api"`

### 2. Fluxo do Sistema (Demonstração CRUD)
1. Faça login como **Fornecedor** (ou use a conta `fornecedor@gmail.com`).
2. No menu lateral, acesse **Meus Anúncios**.
3. Clique em **+ Novo Anúncio** para testar o **Create**.
4. Na lista, use o ícone de **Lápis** para testar o **Update** (carregamento automático).
5. Use o ícone de **Lixeira** para testar o **Delete** (com confirmação).

---

*Desenvolvido sob medida para modernizar as relações B2B de atacado.*
