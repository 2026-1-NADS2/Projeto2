import 'dotenv/config';
import { pool } from '../backend/src/db.js';

async function createTable() {
    try {
        await pool.query_mysql(`
            CREATE TABLE IF NOT EXISTS denuncias (
                id_denuncia SERIAL PRIMARY KEY,
                id_anuncio INT NOT NULL,
                id_usuario_denunciante INT NOT NULL,
                motivo VARCHAR(255) NOT NULL,
                descricao TEXT,
                status VARCHAR(20) DEFAULT 'PENDENTE',
                criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (id_anuncio) REFERENCES anuncios(id_anuncio) ON DELETE CASCADE,
                FOREIGN KEY (id_usuario_denunciante) REFERENCES usuarios(id) ON DELETE CASCADE
            )
        `);
        console.log('Tabela denuncias criada com sucesso!');
        process.exit(0);
    } catch (err) {
        console.error('Erro ao criar tabela:', err);
        process.exit(1);
    }
}

createTable();
