import dotenv from 'dotenv';
import path from 'path';
dotenv.config({ path: path.resolve('backend/.env') });
import { pool } from '../backend/src/db.js';

const images = {
    'Maçã Gala Importada': 'https://images.unsplash.com/photo-1560806887-1e4cd0b6bccb?q=80&w=1000&auto=format&fit=crop',
    'Banana Prata Selecionada': 'https://images.unsplash.com/photo-1571771894821-ad99026107b8?q=80&w=1000&auto=format&fit=crop',
    'Suco de Laranja Integral 1L': 'https://images.unsplash.com/photo-1613478223719-2ab802602423?q=80&w=1000&auto=format&fit=crop',
    'Detergente Neutro 500ml': 'https://andinadistribuidora.com.br/wp-content/uploads/2021/04/detergente-ype-neutro-500ml.png',
    'Camarão Cinza Limpo': 'https://receitadepixe.com.br/wp-content/uploads/2021/03/camarao-cinza.jpg',
    'Desinfetante Lavanda 2L': 'https://images.tcdn.com.br/img/editor/up/1063137/lavanda.png'
};

async function updateImages() {
    try {
        const [rows] = await pool.query_mysql('SELECT id, titulo FROM anuncios');
        console.log(`Encontrados ${rows.length} anúncios.`);

        for (const row of rows) {
            const newUrl = images[row.titulo];
            if (newUrl) {
                console.log(`Atualizando ${row.titulo} -> ${newUrl}`);
                await pool.query_mysql('UPDATE anuncios SET imagem = ? WHERE id = ?', [newUrl, row.id]);
            }
        }

        console.log('Atualização concluída!');
        process.exit(0);
    } catch (err) {
        console.error('Erro ao atualizar:', err);
        process.exit(1);
    }
}

updateImages();
