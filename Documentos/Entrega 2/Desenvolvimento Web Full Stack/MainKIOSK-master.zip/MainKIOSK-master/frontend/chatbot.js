/* Chatbot Juca Logic */
const faqData = [
    { id: 'cadastro', question: 'Como cadastrar um produto?', answer: 'Para cadastrar um produto, acesse sua conta como fornecedor e vá até o painel de anúncios. Clique em "Criar anúncio" e preencha as informações do produto.' },
    { id: 'contato', question: 'Como falar com fornecedores?', answer: 'Você pode entrar em contato com fornecedores diretamente pela página do anúncio, utilizando o botão "Chat Kiosk" ou os dados fornecidos.' },
    { id: 'pagamento', question: 'Preciso pagar para usar?', answer: 'A plataforma funciona apenas como um canal de conexão. A negociação e pagamento são feitos diretamente entre as partes.' },
    { id: 'senha', question: 'Esqueci minha senha', answer: 'Na tela de login, clique em "Esqueci minha senha" para redefinir seu acesso usando seu email e telefone.' },
    { id: 'fraude', question: 'Como denunciar fraude?', answer: 'Utilize o botão de denúncia no perfil do fornecedor ou na página do produto. Analisaremos em até 24h.' }
];

function initChatbot() {
    const container = document.createElement('div');
    container.className = 'chatbot-container';
    container.innerHTML = `
        <div class="chatbot-window" id="chatWindow">
            <div class="chatbot-header">
                <div class="bot-info">
                    <strong>Juca 🤖</strong>
                    <span class="bot-status">Online</span>
                </div>
                <button onclick="toggleChat()" style="background:none; border:none; color:white; cursor:pointer; font-size:1.5rem;">&times;</button>
            </div>
            <div class="chatbot-messages" id="chatMessages">
                <div class="message bot">Oi! Eu sou o Juca 👋 Posso te ajudar com algumas dúvidas rápidas.</div>
                <div class="faq-suggestions" id="faqSuggestions"></div>
            </div>
            <form class="chatbot-input" id="chatForm">
                <input type="text" id="chatInput" placeholder="Digite sua dúvida...">
                <button type="submit"><i class='bx bx-send'></i></button>
            </form>
        </div>
        <div class="chatbot-button" onclick="toggleChat()">
            <img src="imgs/juca.png" alt="Juca">
        </div>
    `;
    document.body.appendChild(container);

    const faqBox = document.getElementById('faqSuggestions');
    faqData.forEach(item => {
        const btn = document.createElement('button');
        btn.className = 'faq-btn';
        btn.innerText = item.question;
        btn.onclick = () => handleFaq(item);
        faqBox.appendChild(btn);
    });

    document.getElementById('chatForm').onsubmit = (e) => {
        e.preventDefault();
        const input = document.getElementById('chatInput');
        if (input.value.trim()) {
            addMessage(input.value, 'user');
            input.value = '';
            addMessage('Ainda estou aprendendo 🤖. Tente uma das opções acima!', 'bot');
        }
    };
}

function toggleChat() {
    document.getElementById('chatWindow').classList.toggle('active');
}

function addMessage(text, sender) {
    const box = document.getElementById('chatMessages');
    const msg = document.createElement('div');
    msg.className = `message ${sender}`;
    msg.innerText = text;
    box.appendChild(msg);
    box.scrollTop = box.scrollHeight;
}

function handleFaq(item) {
    addMessage(item.question, 'user');
    addMessage(item.answer, 'bot');
}

document.addEventListener('DOMContentLoaded', initChatbot);
