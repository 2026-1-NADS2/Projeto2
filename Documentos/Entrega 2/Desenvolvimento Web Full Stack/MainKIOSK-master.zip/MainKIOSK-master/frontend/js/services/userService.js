/**
 * Serviço de Usuário (Perfil, Atualização de Dados)
 */
const UserService = {
    async updateProfile(userData) {
        const token = AuthService.getToken();
        try {
            const data = await ApiService.put('/users/me', userData, token);
            // Atualiza o cache do localStorage com os novos dados
            const currentUser = AuthService.getUser();
            const updatedUser = { ...currentUser, ...userData };
            localStorage.setItem('user', JSON.stringify(updatedUser));
            return data;
        } catch (error) {
            throw error;
        }
    },

    async getProfile(id) {
        const token = AuthService.getToken();
        return await ApiService.get(`/usuarios/${id}`, token);
    }
};

window.UserService = UserService;
