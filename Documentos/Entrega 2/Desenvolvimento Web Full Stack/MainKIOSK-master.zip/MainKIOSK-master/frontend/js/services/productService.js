/**
 * Serviço de Produtos (Catálogo, Anúncios, Categorias)
 */
const ProductService = {
    async getProducts(filters = {}) {
        let url = '/anuncios?limite=100&';
        if (filters.categoria && filters.categoria !== 'all') url += `categoria=${filters.categoria}&`;
        if (filters.busca) url += `busca=${encodeURIComponent(filters.busca)}&`;
        if (filters.id_usuario) url += `id_usuario=${filters.id_usuario}&`;
        
        return await ApiService.get(url);
    },

    async getMyProducts() {
        const token = AuthService.getToken();
        return await ApiService.get('/meus-anuncios', token);
    },

    async getProductById(id) {
        return await ApiService.get(`/anuncios/${id}`);
    },

    async createProduct(formData) {
        const token = AuthService.getToken();
        return await ApiService.post('/anuncios', formData, token, true);
    },

    async updateProduct(id, formData) {
        const token = AuthService.getToken();
        return await ApiService.put(`/anuncios/${id}`, formData, token, true);
    },

    async deleteProduct(id) {
        const token = AuthService.getToken();
        return await ApiService.delete(`/anuncios/${id}`, token);
    },

    async getCategories() {
        return await ApiService.get('/utils/categorias');
    }
};

window.ProductService = ProductService;
