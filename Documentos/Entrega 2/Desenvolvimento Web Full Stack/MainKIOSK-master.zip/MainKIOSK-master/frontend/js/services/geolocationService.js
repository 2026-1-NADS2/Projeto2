// Captura a localização do navegador
const GeolocationService = {
    async getCurrentPosition() {
        return new Promise((resolve, reject) => {
            if (!navigator.geolocation) {
                reject(new Error('Geolocalização não suportada pelo navegador.'));
                return;
            }

            navigator.geolocation.getCurrentPosition(
                (position) => {
                    resolve({
                        lat: position.coords.latitude,
                        lng: position.coords.longitude
                    });
                },
                (error) => {
                    let msg = 'Erro ao obter localização.';
                    switch (error.code) {
                        case error.PERMISSION_DENIED:
                            msg = 'Permissão de localização negada.';
                            break;
                        case error.POSITION_UNAVAILABLE:
                            msg = 'Informações de localização indisponíveis.';
                            break;
                        case error.TIMEOUT:
                            msg = 'Tempo esgotado ao obter localização.';
                            break;
                    }
                    reject(new Error(msg));
                },
                {
                    enableHighAccuracy: true,
                    timeout: 5000,
                    maximumAge: 0
                }
            );
        });
    },

    saveToCache(pos) {
        localStorage.setItem('kiosk_user_pos', JSON.stringify(pos));
    },

    getFromCache() {
        const cache = localStorage.getItem('kiosk_user_pos');
        return cache ? JSON.parse(cache) : null;
    }
};

window.GeolocationService = GeolocationService;
