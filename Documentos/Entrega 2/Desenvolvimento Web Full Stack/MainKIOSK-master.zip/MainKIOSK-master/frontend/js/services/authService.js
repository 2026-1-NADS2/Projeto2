/**
 * Serviço de Autenticação (Login, Cadastro, Recuperação)
 */
const AuthService = {
    async login(email, senha) {
        try {
            const data = await ApiService.post('/auth/login', { email, senha });
            localStorage.setItem("token", data.token);
            localStorage.setItem("user", JSON.stringify(data.user));
            return data;
        } catch (error) {
            throw error;
        }
    },

    async register(userData) {
        try {
            return await ApiService.post('/auth/register', userData);
        } catch (error) {
            throw error;
        }
    },

    async forgotPassword(email, telefone, novaSenha) {
        try {
            return await ApiService.post('/auth/forgot-password', { email, telefone, novaSenha });
        } catch (error) {
            throw error;
        }
    },

    logout() {
        localStorage.clear();
        window.location.href = 'login.html';
    },

    isLoggedIn() {
        return !!localStorage.getItem('token');
    },

    getUser() {
        return JSON.parse(localStorage.getItem('user') || '{}');
    },

    getToken() {
        return localStorage.getItem('token');
    }
};

window.AuthService = AuthService;
