/**
 * Lógica da página de Login/Cadastro (login.html)
 */
document.addEventListener('DOMContentLoaded', () => {
    const loginForm = document.getElementById('loginForm');
    const registerForm = document.getElementById('registerForm');
    const recoveryForm = document.getElementById('recoveryForm');
    const regCnpjInput = document.getElementById('regCnpj');

    // 1. LOGIN
    if (loginForm) {
        loginForm.onsubmit = async (e) => {
            e.preventDefault();
            const email = document.getElementById('loginEmail').value;
            const senha = document.getElementById('loginPass').value;

            try {
                UI.toggleLoading(true);
                const data = await AuthService.login(email, senha);
                UI.showAlert('msg', 'Bem-vindo de volta!', 'success');

                setTimeout(() => {
                    window.location.href = data.user.perfil === 'ADMIN' ? 'admin.html' : 'vitrine.html';
                }, 1000);
            } catch (err) {
                UI.showAlert('msg', err.error || 'Erro ao entrar.', 'error');
            } finally {
                UI.toggleLoading(false);
            }
        };
    }

    // 2. CADASTRO
    if (registerForm) {
        registerForm.onsubmit = async (e) => {
            e.preventDefault();
            const userData = {
                razao_social: document.getElementById('regUser').value,
                cnpj: document.getElementById('regCnpj').value,
                email: document.getElementById('regEmail').value,
                telefone: document.getElementById('regTel').value,
                senha: document.getElementById('regPass').value,
                perfil: 'AMBOS'
            };

            try {
                UI.toggleLoading(true);
                await AuthService.register(userData);
                UI.showAlert('msg', 'Cadastro realizado! Redirecionando...', 'success');
                setTimeout(() => toggleAuth('login'), 1500);
            } catch (err) {
                UI.showAlert('msg', err.error || 'Erro ao realizar cadastro.', 'error');
            } finally {
                UI.toggleLoading(false);
            }
        };
    }

    // 3. RECUPERAÇÃO DE SENHA
    if (recoveryForm) {
        recoveryForm.onsubmit = async (e) => {
            e.preventDefault();
            const email = document.getElementById('recEmail').value;
            const telefone = document.getElementById('recTel').value;
            const novaSenha = document.getElementById('recNewPass').value;

            try {
                UI.toggleLoading(true);
                await AuthService.forgotPassword(email, telefone, novaSenha);
                UI.showAlert('msg', 'Senha redefinida com sucesso!', 'success');
                setTimeout(() => toggleAuth('login'), 2000);
            } catch (err) {
                UI.showAlert('msg', err.error || 'Erro ao redefinir.', 'error');
            } finally {
                UI.toggleLoading(false);
            }
        };
    }

    // 4. CONSULTA CNPJ (Utilitário)
    if (regCnpjInput) {
        regCnpjInput.addEventListener('blur', async (e) => {
            const cnpj = e.target.value.replace(/\D/g, '');
            if (cnpj.length === 14) {
                try {
                    UI.showAlert('msg', 'Consultando CNPJ...', 'success');
                    const data = await ApiService.get(`/utils/cnpj/${cnpj}`);
                    document.getElementById('regUser').value = data.razao_social || '';
                    document.getElementById('regEmail').value = data.email || '';
                    document.getElementById('regTel').value = data.ddd && data.telefone ? `(${data.ddd}) ${data.telefone}` : '';
                    UI.showAlert('msg', 'CNPJ validado!', 'success');
                } catch (err) {
                    UI.showAlert('msg', 'Erro ao consultar CNPJ.', 'error');
                }
            }
        });
    }
});

// Funções globais de UI que precisam ser acessíveis por atributos onclick (legado funcional)
window.toggleAuth = function(state) {
    const body = document.body;
    const loginForm = document.getElementById('loginFormContent');
    const regForm = document.getElementById('registerFormContent');
    const sloganLogin = document.getElementById('sloganLogin');
    const sloganRegister = document.getElementById('sloganRegister');
    const sloganRecovery = document.getElementById('sloganRecovery');
    const formTitle = document.getElementById('formTitle');
    const btns = document.querySelectorAll('.toggle-btn');

    document.querySelector('.form-header').style.display = 'block';
    document.getElementById('recoveryFormContent').classList.remove('active');
    if (sloganRecovery) sloganRecovery.style.display = 'none';

    if (state === 'login') {
        body.className = 'login-state';
        loginForm.classList.add('active');
        regForm.classList.remove('active');
        sloganLogin.style.display = 'block';
        sloganRegister.style.display = 'none';
        formTitle.innerText = 'Login';
        btns[0].classList.add('active');
        btns[1].classList.remove('active');
    } else {
        body.className = 'register-state';
        loginForm.classList.remove('active');
        regForm.classList.add('active');
        sloganLogin.style.display = 'none';
        sloganRegister.style.display = 'block';
        formTitle.innerText = 'Cadastro';
        btns[0].classList.remove('active');
        btns[1].classList.add('active');
    }
}

window.showRecovery = function() {
    const body = document.body;
    const loginForm = document.getElementById('loginFormContent');
    const regForm = document.getElementById('registerFormContent');
    const recoveryForm = document.getElementById('recoveryFormContent');
    const sloganLogin = document.getElementById('sloganLogin');
    const sloganRegister = document.getElementById('sloganRegister');
    const sloganRecovery = document.getElementById('sloganRecovery');
    
    body.className = 'recovery-state';
    loginForm.classList.remove('active');
    regForm.classList.remove('active');
    recoveryForm.classList.add('active');
    
    sloganLogin.style.display = 'none';
    sloganRegister.style.display = 'none';
    sloganRecovery.style.display = 'block';
    document.querySelector('.form-header').style.display = 'none';
}

window.setRecType = function(type) {
    const btnF = document.getElementById('recToggleF');
    const btnC = document.getElementById('recToggleC');
    if (type === 'F') {
        btnF.classList.add('active');
        btnC.classList.remove('active');
    } else {
        btnC.classList.add('active');
        btnF.classList.remove('active');
    }
}
