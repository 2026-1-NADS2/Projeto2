/**
 * Lógica da Vitrine de Produtos (vitrine.html)
 */
document.addEventListener('DOMContentLoaded', () => {
    const searchInput = document.getElementById('searchInput');
    const searchBtn = document.querySelector('.search-btn');

    // Inicialização da página
    checkProfile();
    initGeolocation();
    loadProducts();

    // 2. BUSCA
    if (searchInput) {
        searchInput.addEventListener('keypress', (e) => {
            if (e.key === 'Enter') {
                const search = e.target.value;
                loadProducts('', search);
            }
        });
    }

    if (searchBtn) {
        searchBtn.addEventListener('click', () => {
            const search = document.getElementById('searchInput').value;
            loadProducts('', search);
        });
    }

    // 3. CATEGORIAS NA NAVBAR
    document.querySelectorAll('#navCategories a').forEach(link => {
        link.addEventListener('click', (e) => {
            e.preventDefault();
            const cat = link.getAttribute('data-cat');
            filterCategory(cat);
        });
    });
});

/**
 * Função global para carregar produtos na grid
 */
window.loadProducts = async function (categoria = '', busca = '') {
    const grid = document.getElementById('productsGrid');
    if (!grid) return;

    grid.innerHTML = '<p>Carregando produtos...</p>';

    try {
        let products = await ProductService.getProducts({ categoria, busca });
        const userPos = GeolocationService.getFromCache();

        // Ordenação por proximidade
        if (userPos) {
            products = products.map(p => {
                const dist = DistanceUtils.calculate(userPos.lat, userPos.lng, p.latitude, p.longitude);
                return { ...p, distancia: dist };
            });

            // Ordenar por proximidade (mais próximos primeiro)
            products.sort((a, b) => {
                if (a.distancia === null) return 1;
                if (b.distancia === null) return -1;
                return a.distancia - b.distancia;
            });
        }

        grid.innerHTML = '';
        if (products.length === 0) {
            grid.innerHTML = '<p>Nenhum produto encontrado.</p>';
            return;
        }

        products.forEach(p => {
            const isFav = favorites.some(fav => fav.id_anuncio === p.id_anuncio);
            const distLabel = p.distancia !== undefined ?
                `<span class="product-distance"><i class='bx bx-map-pin'></i> ${DistanceUtils.format(p.distancia)}</span>` : '';

            const productEncoded = encodeURIComponent(JSON.stringify(p));
            const card = document.createElement('div');
            card.className = 'product-card';
            card.innerHTML = `
                <div class="fav-heart ${isFav ? 'active' : ''}" onclick="toggleFavorite(event, '${productEncoded}')">
                    <i class='bx ${isFav ? 'bxs-heart' : 'bx-heart'}'></i>
                </div>
                <div class="product-img-container">
                    <img src="${p.imagem_principal || 'https://via.placeholder.com/300?text=Kiosk'}" alt="${p.titulo}" onerror="this.src='https://via.placeholder.com/300?text=Erro'">
                </div>
                <div class="product-info">
                    <div style="display: flex; justify-content: space-between; align-items: flex-start;">
                        <h4>${p.titulo}</h4>
                        ${distLabel}
                    </div>
                    <div class="product-price">
                        <span class="currency">R$</span>
                        <span class="value">${parseFloat(p.preco_unitario || 0).toLocaleString('pt-BR', { minimumFractionDigits: 2 })}</span>
                        <span class="unit">/${p.unidade || 'un'}</span>
                    </div>
                    <p class="product-vendor"><i class='bx bx-store'></i> ${p.fornecedor || p.razao_social || 'Fornecedor'}</p>
                </div>
            `;
            card.onclick = (e) => {
                if (e.target.closest('.fav-heart')) return;
                window.location.href = `detalhes.html?id=${p.id_anuncio}`;
            };
            grid.appendChild(card);
        });
    } catch (err) {
        console.error(err);
        grid.innerHTML = '<p>Erro ao carregar produtos.</p>';
    }
}

/**
 * Função global para filtrar por categoria com efeitos visuais
 */
window.filterCategory = function (cat) {
    const hero = document.getElementById('hero');
    const banner = document.getElementById('categoryBanner');
    const navCats = document.getElementById('navCategories');
    const gridTitle = document.getElementById('gridTitle');
    const bannerTitle = document.getElementById('bannerTitle');
    const navbar = document.querySelector('.vitrine-navbar');
    const bubbles = document.getElementById('categoriesBubbles');

    document.getElementById('searchInput').value = '';
    window.scrollTo({ top: 0, behavior: 'smooth' });

    if (cat === 'all') {
        if (hero) { hero.style.height = '600px'; hero.style.opacity = '1'; }
        if (banner) banner.style.display = 'none';
        if (bubbles) bubbles.style.display = 'flex';
        navCats.classList.remove('show');
        navbar.classList.remove('navbar-white');
        gridTitle.innerText = 'Todos os Produtos';
    } else {
        if (hero) { hero.style.height = '0'; hero.style.opacity = '0'; }
        if (banner) banner.style.display = 'block';
        if (bubbles) bubbles.style.display = 'none';
        navCats.classList.add('show');
        navbar.classList.add('navbar-white');
        gridTitle.innerText = `Resultados para ${cat}`;
        if (bannerTitle) bannerTitle.innerText = cat;
    }

    document.querySelectorAll('#navCategories a').forEach(l => {
        l.classList.toggle('active', l.getAttribute('data-cat') === cat);
    });

    loadProducts(cat);
}

/**
 * Favoritos (LocalStorage por enquanto, mas usando objeto centralizado)
 */
window.toggleFavorite = function (event, productStr) {
    event.stopPropagation();
    const product = JSON.parse(decodeURIComponent(productStr));
    if (user && user.id === product.id_usuario) {
        alert('Você não pode favoritar seus próprios produtos.');
        return;
    }

    let favorites = JSON.parse(localStorage.getItem('kiosk_favorites') || '[]');
    const index = favorites.findIndex(fav => fav.id_anuncio === product.id_anuncio);

    const heartDiv = event.currentTarget;
    const heartIcon = heartDiv.querySelector('i');

    if (index > -1) {
        favorites.splice(index, 1);
        heartDiv.classList.remove('active');
        heartIcon.className = 'bx bx-heart';
    } else {
        favorites.push(product);
        heartDiv.classList.add('active');
        heartIcon.className = 'bx bxs-heart';
    }

    localStorage.setItem('kiosk_favorites', JSON.stringify(favorites));
}

/**
 * Validação de Perfil e Visibilidade de Botões
 */
window.checkProfile = function () {
    const user = AuthService.getUser();
    if (!AuthService.isLoggedIn()) return;

    const btnFornecedor = document.getElementById('btnPainelFornecedor');
    const btnAdmin = document.getElementById('btnPainelAdmin');
    const linkAdminSidebar = document.getElementById('linkAdminSidebar');

    if (user.perfil === 'ADMIN') {
        if (btnFornecedor) btnFornecedor.style.display = 'none';
        if (btnAdmin) btnAdmin.style.display = 'flex';
        if (linkAdminSidebar) linkAdminSidebar.style.display = 'block';
    } else if (user.perfil === 'FORNECEDOR' || user.perfil === 'AMBOS') {
        if (btnFornecedor) btnFornecedor.style.display = 'flex';
    }
}

window.logout = () => AuthService.logout();

// Menu Drawer
const sideMenu = document.getElementById('sideMenu');
const openSideBtn = document.getElementById('openSideMenu');
const closeSideBtn = document.querySelector('.close-side-menu');
const menuOverlay = document.getElementById('sideMenuOverlay');

if (openSideBtn) {
    openSideBtn.addEventListener('click', () => {
        sideMenu.classList.add('active');
        menuOverlay.classList.add('active');
    });
}

const closeMenu = () => {
    if (sideMenu) sideMenu.classList.remove('active');
    if (menuOverlay) menuOverlay.classList.remove('active');
};

if (closeSideBtn) closeSideBtn.addEventListener('click', closeMenu);
if (menuOverlay) menuOverlay.addEventListener('click', closeMenu);

// Modal Usuário
const userModal = document.getElementById('userModal');
const openUserBtn = document.getElementById('openUserModal');
const closeUserBtn = document.querySelector('#userModal .close-modal');

if (openUserBtn) {
    openUserBtn.addEventListener('click', () => {
        const user = AuthService.getUser();
        if (user.perfil === 'FORNECEDOR' || user.perfil === 'AMBOS') {
            window.location.href = `perfil-fornecedor.html?id=${user.id}&edit=true`;
            return;
        }
        document.getElementById('userName').value = user.razao_social || user.nome || '';
        document.getElementById('userEmail').value = user.email || '';
        document.getElementById('userPhone').value = user.telefone || '';
        userModal.style.display = 'flex';
        setTimeout(() => userModal.classList.add('show'), 10);
    });
}

if (closeUserBtn) {
    closeUserBtn.addEventListener('click', () => {
        userModal.classList.remove('show');
        setTimeout(() => { userModal.style.display = 'none'; }, 300);
    });
}

// Inicialização de Geolocalização
window.initGeolocation = async function () {
    try {
        const pos = await GeolocationService.getCurrentPosition();
        GeolocationService.saveToCache(pos);
        // Recarrega produtos para aplicar ordenação por distância
        loadProducts();
    } catch (err) {
        console.warn('Geolocalização ignorada:', err.message);
    }
}

// 4. ATUALIZAÇÃO DE PERFIL REAL (FIM DA SIMULAÇÃO)
const userDataForm = document.getElementById('userDataForm');
if (userDataForm) {
    userDataForm.onsubmit = async (e) => {
        e.preventDefault();
        const updatedData = {
            razao_social: document.getElementById('userName').value,
            email: document.getElementById('userEmail').value,
            telefone: document.getElementById('userPhone').value
        };

        try {
            UI.toggleLoading(true);
            await UserService.updateProfile(updatedData);
            UI.showAlert('msg-perfil', 'Dados atualizados com sucesso!', 'success'); // Precisa criar esse ID no HTML ou usar UI.showAlert global

            // Feedback visual e fecha modal
            setTimeout(() => {
                userModal.classList.remove('show');
                setTimeout(() => { userModal.style.display = 'none'; }, 300);
            }, 1500);
        } catch (err) {
            alert(err.error || 'Erro ao atualizar dados.');
        } finally {
            UI.toggleLoading(false);
        }
    };
}
