const isLocal = window.location.hostname === 'localhost' || window.location.hostname === '127.0.0.1';

const CONFIG = {
    API_URL: isLocal ? "http://localhost:3000/api" : "/api",
    BASE_URL: isLocal ? "http://localhost:3000" : window.location.origin
};

window.CONFIG = CONFIG;
