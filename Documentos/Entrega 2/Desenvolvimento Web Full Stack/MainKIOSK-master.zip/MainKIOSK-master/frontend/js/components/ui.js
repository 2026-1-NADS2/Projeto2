/**
 * Componentes de UI reutilizáveis (Alertas, Loading, Modais)
 */
const UI = {
    /**
     * Exibe um alerta na tela
     * @param {string} elementId ID do elemento onde a msg será injetada
     * @param {string} message Texto da mensagem
     * @param {string} type 'success' ou 'error'
     */
    showAlert(elementId, message, type = 'success') {
        const msgElement = document.getElementById(elementId);
        if (!msgElement) return;

        msgElement.innerText = message;
        msgElement.className = `msg ${type}`;
        msgElement.style.display = 'block';

        // Estilo inline básico para garantir visibilidade se o CSS falhar
        msgElement.style.color = type === 'success' ? '#2b6024' : '#c62828';
        
        if (type === 'success') {
            setTimeout(() => {
                msgElement.innerText = '';
                msgElement.style.display = 'none';
            }, 4000);
        }
    },

    /**
     * Controla o overlay de carregamento
     * @param {boolean} show 
     */
    toggleLoading(show = true) {
        let loader = document.getElementById('loadingOverlay') || document.getElementById('loading');
        if (!loader) {
            // Cria um se não existir
            loader = document.createElement('div');
            loader.id = 'loadingOverlay';
            loader.innerHTML = '<div class="loader-content"><i class="bx bx-loader-alt bx-spin"></i><span> Carregando...</span></div>';
            document.body.appendChild(loader);
        }
        loader.style.display = show ? 'flex' : 'none';
    },

    /**
     * Formata moeda para Real Brasileiro
     * @param {number} value 
     */
    formatCurrency(value) {
        return parseFloat(value || 0).toLocaleString('pt-BR', {
            style: 'currency',
            currency: 'BRL'
        });
    },

    /**
     * Formata data para padrão brasileiro
     * @param {string} dateStr 
     */
    formatDate(dateStr) {
        if (!dateStr) return '-';
        return new Date(dateStr).toLocaleDateString('pt-BR');
    }
};

window.UI = UI;
