// Serviço centralizado de chamadas à API
const ApiService = {
    async get(endpoint, token = null) {
        const headers = { 'Content-Type': 'application/json' };
        if (token) headers['Authorization'] = `Bearer ${token}`;

        try {
            const res = await fetch(`${window.CONFIG.API_URL}${endpoint}`, { headers });
            if (!res.ok) throw await res.json();
            return await res.json();
        } catch (error) {
            console.error(`Erro em GET ${endpoint}:`, error);
            throw error;
        }
    },

    async post(endpoint, data, token = null, isFormData = false) {
        const headers = {};
        if (token) headers['Authorization'] = `Bearer ${token}`;
        if (!isFormData) headers['Content-Type'] = 'application/json';

        try {
            const res = await fetch(`${window.CONFIG.API_URL}${endpoint}`, {
                method: 'POST',
                headers,
                body: isFormData ? data : JSON.stringify(data)
            });
            if (!res.ok) throw await res.json();
            return await res.json();
        } catch (error) {
            console.error(`Erro em POST ${endpoint}:`, error);
            throw error;
        }
    },

    async put(endpoint, data, token = null, isFormData = false) {
        const headers = {};
        if (token) headers['Authorization'] = `Bearer ${token}`;
        if (!isFormData) headers['Content-Type'] = 'application/json';

        try {
            const res = await fetch(`${window.CONFIG.API_URL}${endpoint}`, {
                method: 'PUT',
                headers,
                body: isFormData ? data : JSON.stringify(data)
            });
            if (!res.ok) throw await res.json();
            return await res.json();
        } catch (error) {
            console.error(`Erro em PUT ${endpoint}:`, error);
            throw error;
        }
    },

    async delete(endpoint, token = null) {
        const headers = { 'Content-Type': 'application/json' };
        if (token) headers['Authorization'] = `Bearer ${token}`;

        try {
            const res = await fetch(`${window.CONFIG.API_URL}${endpoint}`, {
                method: 'DELETE',
                headers
            });
            if (!res.ok) throw await res.json();
            return await res.json();
        } catch (error) {
            console.error(`Erro em DELETE ${endpoint}:`, error);
            throw error;
        }
    }
};

window.ApiService = ApiService;
