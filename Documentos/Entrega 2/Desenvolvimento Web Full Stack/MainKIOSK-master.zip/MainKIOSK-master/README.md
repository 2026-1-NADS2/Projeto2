# Kiosk - Plataforma B2B para o Mercado de Alimentação e Bebidas 🛒🌱

O **Kiosk** é um marketplace B2B projetado para conectar produtores rurais, distribuidores e lojistas. A plataforma facilita a negociação direta, a compra por atacado e a gestão de produtos com uma interface moderna e responsiva.

---

## 🚀 Como Rodar o Projeto

Siga os passos abaixo para configurar os ambientes de Backend e Frontend na sua máquina local.

### 1. Pré-requisitos
- [Node.js](https://nodejs.org/) instalado.
- [PostgreSQL](https://www.postgresql.org/) (ou acesso a uma instância na nuvem, como o Neon DB).

### 2. Configurando o Backend (Servidor)
1.  Navegue até a pasta do backend:
    ```bash
    cd backend
    ```
2.  Instale as dependências:
    ```bash
    npm install
    ```
3.  Configure as variáveis de ambiente (veja a seção [Configuração da API](#-configuração-da-url-da-api)).
4.  Inicie o servidor:
    ```bash
    npm run dev
    # ou
    npm start
    ```
    *O servidor estará rodando em `http://localhost:3000`.*

### 3. Acessando o Frontend
O frontend é composto por arquivos estáticos e não requer um passo de build.
1.  Abra a pasta `frontend/`.
2.  Inicie o arquivo `login.html` ou `index.html` diretamente no navegador.
3.  **Recomendado**: Use a extensão **Live Server** do VS Code para uma melhor experiência com hot-reload.

---

## ⚙️ Configuração da URL da API

Para que o sistema funcione corretamente, o frontend e o backend precisam estar sincronizados.

### Backend (`backend/.env`)
Crie um arquivo `.env` na pasta `backend` com as seguintes chaves:
```env
DATABASE_URL=sua_url_do_postgres
JWT_SECRET=sua_chave_secreta
PORT=3000
```

### Frontend (`frontend/js/config.js`)
A URL da API é configurada centralizadamente. O arquivo detecta automaticamente se você está rodando localmente:
```javascript
const isLocal = window.location.hostname === 'localhost' || window.location.hostname === '127.0.0.1';

const CONFIG = {
    API_URL: isLocal ? "http://localhost:3000/api" : "/api",
    BASE_URL: isLocal ? "http://localhost:3000" : window.location.origin
};
```
*Se o seu backend estiver em uma porta ou endereço diferente, altere o valor de `API_URL` acima.*

---

## 🗺️ Fluxo de Telas

O sistema possui fluxos distintos dependendo do perfil do usuário logado.

```mermaid
graph TD
    A[index.html / login.html] -->|Cadastrar| B[cadastro.html]
    A -->|Login Lojista| C[vitrine.html]
    A -->|Login Fornecedor| D[dashboard-fornecedor.html]
    A -->|Login Admin| E[admin.html]

    subgraph Fluxo_Lojista
        C -->|Ver Produto| F[detalhes.html]
        C -->|Favoritos| G[favoritos.html]
        C -->|Meus Pedidos| H[pedidos-lojista.html]
        C -->|Chat| I[chat-lojista.html]
    end

    subgraph Fluxo_Fornecedor
        D -->|Gerenciar Produtos| J[meus-produtos.html]
        J -->|Novo Anúncio| K[criar_anuncio.html]
        J -->|Editar| L[editar_anuncio.html]
        D -->|Pedidos Recebidos| M[pedidos-fornecedor.html]
        D -->|Chat| N[chat-fornecedor.html]
        D -->|Perfil/Selos| O[perfil-fornecedor.html]
    end

    subgraph Fluxo_Admin
        E -->|Moderação| P[aprovacao_anuncios.html]
        E -->|Denúncias| Q[admin.html]
    end
```

### Descrição dos Perfis:
- **Lojista**: Focado em descobrir produtos na vitrine, favoritar itens e realizar pedidos.
- **Fornecedor**: Focado na gestão do catálogo (CRUD de anúncios), acompanhamento de vendas e conquistas/selos.
- **Administrador**: Responsável por moderar novos anúncios e gerenciar denúncias de usuários.

---

## 🛠️ Tecnologias Utilizadas
- **Backend**: Node.js, Express, PostgreSQL, JWT.
- **Frontend**: HTML5, CSS3 (Vanilla), JavaScript (Vanilla).
- **Comunicação**: Socket.io (Chat em tempo real).

---
*Desenvolvido para modernizar as relações comerciais no setor de alimentação.*
