import 'dotenv/config';
import bcrypt from 'bcrypt';
import { pool } from './src/db.js';

async function createAdmin() {
    const email = 'administrador@gmail.com';
    const senha = '123';
    const cnpj = '00.000.000/0001-00';
    const razao_social = 'Kiosk Admin';
    const perfil = 'ADMIN';

    try {
        const hashedPass = await bcrypt.hash(senha, 10);
        await pool.query_mysql(
            'INSERT INTO usuarios (razao_social, email, senha, cnpj, perfil) VALUES (?, ?, ?, ?, ?)',
            [razao_social, email, hashedPass, cnpj, perfil]
        );
        console.log('Usuário Administrador criado com sucesso!');
    } catch (err) {
        if (err.code === '23505') {
            console.log('Usuário Administrador já existe.');
        } else {
            console.error('Erro ao criar administrador:', err.message);
        }
    }
    process.exit();
}

createAdmin();
