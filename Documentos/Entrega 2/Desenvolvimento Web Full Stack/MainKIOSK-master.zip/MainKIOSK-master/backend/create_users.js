import 'dotenv/config';
import bcrypt from 'bcrypt';
import { pool } from './src/db.js';

async function createUsers() {
    const users = [
        {
            razao_social: 'Lojista GERAL',
            nome_fantasia: 'Lojista GERAL',
            cnpj: '14.380.200/0001-21',
            email: 'lojista@gmail.com',
            telefone: '(11) 99999-9999',
            senha: '123',
            perfil: 'COMPRADOR'
        },
        {
            razao_social: 'Fornecedor GERAL',
            nome_fantasia: 'Fornecedor GERAL',
            cnpj: '13.347.016/0001-17',
            email: 'fornecedor@gmail.com',
            telefone: '(11) 88888-8888',
            senha: '123',
            perfil: 'FORNECEDOR'
        }
    ];

    for (const user of users) {
        try {
            const hash = await bcrypt.hash(user.senha, 10);
            const [rows] = await pool.query_mysql(
                'INSERT INTO usuarios (razao_social, nome_fantasia, cnpj, email, telefone, senha, perfil, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?) RETURNING id',
                [user.razao_social, user.nome_fantasia, user.cnpj, user.email, user.telefone, hash, user.perfil, 'ATIVO']
            );
            console.log(`Usuário criado com sucesso: ${user.email} (ID: ${rows[0].id})`);
        } catch (err) {
            if (err.code === '23505') {
                console.log(`Usuário já existe: ${user.email} ou CNPJ ${user.cnpj}`);
            } else {
                console.error(`Erro ao criar usuário ${user.email}:`, err.message);
            }
        }
    }
    process.exit();
}

createUsers();
