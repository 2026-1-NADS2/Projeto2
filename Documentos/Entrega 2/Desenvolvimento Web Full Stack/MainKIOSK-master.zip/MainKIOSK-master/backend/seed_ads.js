import { pool } from './src/db.js';

async function seed() {
    console.log('Iniciando seed de anúncios...');

    try {
        // Pega as categorias
        const [categories] = await pool.query_mysql('SELECT id_categoria, nome FROM categorias');
        if (categories.length === 0) {
            console.error('Nenhuma categoria encontrada. Execute o seed de categorias primeiro.');
            return;
        }

        const ads = [
            {
                titulo: 'Alface Crespa Premium',
                descricao: 'Alface fresquinha colhida no dia.',
                id_categoria: categories.find(c => c.nome === 'Verduras')?.id_categoria,
                unidade: 'Maço',
                marca: 'Horta do Zé',
                pedido_minimo: 10,
                regiao_atendida: 'São Paulo',
                prazo_entrega: '24h',
                formas_contato: 'WhatsApp',
                status: 'ATIVO',
                preco_unitario: 2.50,
                estoque: 100
            },
            {
                titulo: 'Picanha Bovina',
                descricao: 'Corte premium de picanha.',
                id_categoria: categories.find(c => c.nome === 'Carnes')?.id_categoria,
                unidade: 'kg',
                marca: 'Friboi',
                pedido_minimo: 5,
                regiao_atendida: 'Todo o Brasil',
                prazo_entrega: '3 dias',
                formas_contato: 'Chat',
                status: 'ATIVO',
                preco_unitario: 89.90,
                estoque: 50
            },
            {
                titulo: 'Cerveja Lata 350ml',
                descricao: 'Pack com 12 unidades.',
                id_categoria: categories.find(c => c.nome === 'Bebidas')?.id_categoria,
                unidade: 'Pack',
                marca: 'Skol',
                pedido_minimo: 20,
                regiao_atendida: 'São Paulo',
                prazo_entrega: '48h',
                formas_contato: 'WhatsApp',
                status: 'ATIVO',
                preco_unitario: 35.00,
                estoque: 200
            }
        ];

        for (const ad of ads) {
            const [existing] = await pool.query_mysql('SELECT id_anuncio FROM anuncios WHERE titulo = ?', [ad.titulo]);
            
            if (existing.length === 0) {
                await pool.query_mysql(
                    `INSERT INTO anuncios (
                        id_usuario, id_categoria, titulo, descricao, unidade, marca, 
                        pedido_minimo, regiao_atendida, prazo_entrega, formas_contato, 
                        status, preco_unitario, estoque
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
                    [
                        1, ad.id_categoria, ad.titulo, ad.descricao, ad.unidade, ad.marca,
                        ad.pedido_minimo, ad.regiao_atendida, ad.prazo_entrega, ad.formas_contato,
                        ad.status, ad.preco_unitario, ad.estoque
                    ]
                );
                console.log(`Anúncio adicionado: ${ad.titulo}`);
            } else {
                console.log(`Anúncio já existe: ${ad.titulo}`);
            }
        }
        console.log('Seed de anúncios concluído com sucesso!');
    } catch (err) {
        console.error('Erro no seed de anúncios:', err);
    } finally {
        process.exit();
    }
}

seed();
