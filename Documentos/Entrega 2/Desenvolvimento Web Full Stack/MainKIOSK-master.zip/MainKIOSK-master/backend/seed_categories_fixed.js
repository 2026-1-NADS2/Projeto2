import { pool } from './src/db.js';

async function seed() {
    const categories = [
        { nome: 'Verduras', icone: 'bx-leaf', cor: '#2B6024' },
        { nome: 'Carnes', icone: 'bx-bowl-hot', cor: '#CA871A' },
        { nome: 'Peixes', icone: 'bx-water', cor: '#2196F3' },
        { nome: 'Frutas', icone: 'bx-apple', cor: '#F44336' },
        { nome: 'Bebidas', icone: 'bx-drink', cor: '#1A237E' },
        { nome: 'Limpeza e Higiene', icone: 'bx-brush', cor: '#7B1FA2' },
        { nome: 'Sustentável', icone: 'bx-recycle', cor: '#4CAF50' }
    ];

    console.log('Iniciando seed de categorias...');

    try {
        for (const cat of categories) {
            // Verifica se a categoria já existe
            const [existing] = await pool.query_mysql('SELECT id_categoria FROM categorias WHERE nome = ?', [cat.nome]);
            
            if (existing.length === 0) {
                await pool.query_mysql(
                    'INSERT INTO categorias (nome, icone, cor) VALUES (?, ?, ?)',
                    [cat.nome, cat.icone, cat.cor]
                );
                console.log(`Categoria adicionada: ${cat.nome}`);
            } else {
                console.log(`Categoria já existe: ${cat.nome}`);
            }
        }
        console.log('Seed concluído com sucesso!');
    } catch (err) {
        console.error('Erro no seed:', err);
    } finally {
        process.exit();
    }
}

seed();
