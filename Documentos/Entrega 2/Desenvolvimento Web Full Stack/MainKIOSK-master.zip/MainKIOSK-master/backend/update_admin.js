import 'dotenv/config';
import bcrypt from 'bcrypt';
import { pool } from './src/db.js';

async function updateAdminPassword() {
    const email = 'administrador@gmail.com';
    const novaSenha = 'piGoing@132';

    try {
        const hashedPass = await bcrypt.hash(novaSenha, 10);
        const [result] = await pool.query_mysql(
            'UPDATE usuarios SET senha = ? WHERE email = ?',
            [hashedPass, email]
        );
        console.log('Senha do Administrador atualizada com sucesso!');
    } catch (err) {
        console.error('Erro ao atualizar senha do administrador:', err.message);
    }
    process.exit();
}

updateAdminPassword();
