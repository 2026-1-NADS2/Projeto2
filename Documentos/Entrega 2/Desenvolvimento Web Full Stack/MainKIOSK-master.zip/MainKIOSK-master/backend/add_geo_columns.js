import { pool } from './src/db.js';

async function migrate() {
    console.log('Iniciando migração de geolocalização...');
    try {
        await pool.query_mysql(`
            ALTER TABLE usuarios 
            ADD COLUMN IF NOT EXISTS latitude DECIMAL(10, 8),
            ADD COLUMN IF NOT EXISTS longitude DECIMAL(11, 8)
        `);
        console.log('Colunas latitude e longitude adicionadas com sucesso!');
        
        // Mock de dados reais para teste (opcional, apenas para os fornecedores existentes terem uma base)
        // Colocando coordenadas de São Paulo como base
        await pool.query_mysql(`
            UPDATE usuarios 
            SET latitude = -23.550520, longitude = -46.633308 
            WHERE perfil IN ('FORNECEDOR', 'AMBOS') AND latitude IS NULL
        `);
        console.log('Coordenadas base aplicadas aos fornecedores.');
    } catch (err) {
        console.error('Erro na migração:', err);
    }
}

migrate();
