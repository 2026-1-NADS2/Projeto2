import 'dotenv/config';
import fs from 'fs';
import { pool } from './src/db.js';

const FORNECEDOR_ID = 20;

async function updateProfile() {
    console.log('Iniciando atualização do perfil...');

    const logoPath = 'C:\\Users\\davib\\.gemini\\antigravity\\brain\\0688dd13-3cad-4f16-b979-367cc54b789a\\hortifruit_logo_1778428781087.png';
    const bannerPath = 'C:\\Users\\davib\\.gemini\\antigravity\\brain\\0688dd13-3cad-4f16-b979-367cc54b789a\\hortifruit_banner_1778428796851.png';

    let avatarBase64 = '';
    let bannerBase64 = '';

    try {
        const logoBuffer = fs.readFileSync(logoPath);
        avatarBase64 = `data:image/png;base64,${logoBuffer.toString('base64')}`;
        
        const bannerBuffer = fs.readFileSync(bannerPath);
        bannerBase64 = `data:image/png;base64,${bannerBuffer.toString('base64')}`;
    } catch (err) {
        console.error('Erro ao ler imagens:', err.message);
    }

    const descricao = 'O Hortifruit do Bairro é o seu parceiro de confiança para produtos frescos e de qualidade. Levamos o melhor da fazenda diretamente para o seu negócio, com entregas rápidas e um atendimento personalizado. Qualidade que você sente, frescor que você vê.';

    try {
        await pool.query_mysql(
            'UPDATE usuarios SET nome_fantasia = ?, razao_social = ?, descricao = ?, avatar = ?, banner = ? WHERE id = ?',
            ['Hortifruit do Bairro', 'Hortifruit do Bairro LTDA', descricao, avatarBase64, bannerBase64, FORNECEDOR_ID]
        );
        console.log('Perfil atualizado com sucesso!');
    } catch (err) {
        console.error('Erro ao atualizar perfil:', err.message);
    }

    process.exit();
}

updateProfile();
