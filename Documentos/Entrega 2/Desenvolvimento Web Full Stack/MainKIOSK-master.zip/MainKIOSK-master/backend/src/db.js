import 'dotenv/config';
import pg from 'pg';

const { Pool } = pg;

const pgPool = new Pool({
    connectionString: process.env.DATABASE_URL,
    ssl: {
        rejectUnauthorized: false
    }
});

// Wrapper para converter sintaxe MySQL (?) para Postgres ($1)
// Usamos pgPool diretamente para evitar recursão
export const pool = {
    query_mysql: async (text, params = []) => {
        let pgText = text;
        let count = 1;
        pgText = text.replace(/\?/g, () => `$${count++}`);

        try {
            const res = await pgPool.query(pgText, params);
            return [res.rows, res.fields];
        } catch (err) {
            console.error('--- ERRO NO BANCO DE DADOS ---');
            console.error('Query:', pgText);
            console.error('Parâmetros:', params);
            console.error('Erro:', err.message);
            console.error('-------------------------------');
            throw err;
        }
    },

    getConnection: async () => {
        const client = await pgPool.connect();

        return {
            query_mysql: async (text, params = []) => {
                let pgText = text;
                let count = 1;
                pgText = text.replace(/\?/g, () => `$${count++}`);
                try {
                    const res = await client.query(pgText, params);
                    return [res.rows, res.fields];
                } catch (err) {
                    console.error('--- ERRO NO BANCO DE DADOS (TRANSACTION) ---');
                    console.error('Query:', pgText);
                    console.error('Parâmetros:', params);
                    console.error('Erro:', err.message);
                    console.error('-------------------------------------------');
                    throw err;
                }
            },
            beginTransaction: () => client.query('BEGIN'),
            commit: async () => {
                await client.query('COMMIT');
            },
            rollback: async () => {
                await client.query('ROLLBACK');
            },
            release_mysql: () => client.release()
        };
    }
};