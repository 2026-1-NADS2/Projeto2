import { Router } from 'express';
import upload from './uploadConfig.js';
import { verifyTokenMiddleware } from './middlewares/authMiddleware.js';
import { roleMiddleware } from './middlewares/roleMiddleware.js';

// Controllers
import { register, login, logout, forgotPassword } from './controllers/authController.js';
import { getUsuarios, getUsuarioById, updateMe, profile, deleteMe, getFornecedores } from './controllers/userController.js';
import { consultarCNPJ, getCategorias } from './controllers/utilsController.js';
import { createAnuncio, getAnuncios, getAnuncioById, getMeusAnuncios, updateAnuncio, deleteAnuncio } from './controllers/anuncioController.js';
import { createAvaliacao, getAvaliacoesAnuncio, toggleFavorito, getMeusFavoritos, criarDenuncia } from './controllers/interacaoController.js';
import { iniciarChat, getMeusChats, enviarMensagem, getMensagens } from './controllers/chatController.js';
import { moderarAnuncio, moderarUsuario, moderarAvaliacao, relatorios, getAnunciosPendentes, getRelatorioPedidos, getDenunciasPendentes, resolverDenuncia } from './controllers/adminController.js';
import { getSupplierStats, getLojistaStats } from './controllers/dashboardController.js';
import { createOrder, getOrders, updateOrderStatus } from './controllers/orderController.js';
import { getMeusSelos } from './controllers/gamificationController.js';

const r = Router();

// --- PÚBLICAS ---
r.post('/auth/register', register);
r.post('/auth/login', login);
r.post('/auth/forgot-password', forgotPassword);
r.get('/utils/cnpj/:cnpj', consultarCNPJ);
r.get('/utils/categorias', getCategorias);
r.get('/anuncios', getAnuncios);
r.get('/anuncios/:id', getAnuncioById);
r.get('/anuncios/:id_anuncio/avaliacoes', getAvaliacoesAnuncio);
r.get('/fornecedores', getFornecedores);

// --- PROTEGIDAS ---
r.use(verifyTokenMiddleware); // Aplica a todas abaixo
r.post('/auth/logout', logout);

// Perfil de Usuário
r.get('/users/profile', profile);
r.put('/users/me', updateMe);
r.delete('/users/me', deleteMe);
r.get('/users', getUsuarios);
r.get('/users/:id', getUsuarioById);

// --- DASHBOARD & GAMIFICATION ---
r.get('/dashboard/fornecedor', roleMiddleware(['FORNECEDOR', 'AMBOS']), getSupplierStats);
r.get('/dashboard/lojista', roleMiddleware(['COMPRADOR', 'AMBOS']), getLojistaStats);
r.get('/gamification/meus-selos', getMeusSelos);

// --- PEDIDOS ---
r.post('/pedidos', roleMiddleware(['COMPRADOR', 'AMBOS']), createOrder);
r.get('/pedidos', getOrders);
r.put('/pedidos/:id/status', updateOrderStatus);

// --- FORNECEDOR (ANÚNCIOS) ---
const fornecedorOnly = roleMiddleware(['FORNECEDOR', 'AMBOS']);
r.post('/anuncios', fornecedorOnly, upload.array('imagens', 5), createAnuncio);
r.get('/meus-anuncios', fornecedorOnly, getMeusAnuncios);
r.put('/anuncios/:id', fornecedorOnly, upload.array('imagens', 5), updateAnuncio);
r.delete('/anuncios/:id', fornecedorOnly, deleteAnuncio);

// --- COMPRADOR ---
const compradorOnly = roleMiddleware(['COMPRADOR', 'AMBOS']);
r.post('/avaliacoes', compradorOnly, createAvaliacao);
r.post('/favoritos', compradorOnly, toggleFavorito);
r.get('/meus-favoritos', compradorOnly, getMeusFavoritos);
r.post('/anuncios/:id/denunciar', compradorOnly, criarDenuncia);

// --- CHAT INTERNO (Ambos) ---
r.post('/chats', compradorOnly, iniciarChat); // Comprador inicia
r.get('/chats', getMeusChats);
r.post('/chats/:id_chat/mensagens', enviarMensagem);
r.get('/chats/:id_chat/mensagens', getMensagens);

// --- ADMIN ---
const adminOnly = roleMiddleware(['ADMIN']);
r.get('/admin/anuncios/pendentes', adminOnly, getAnunciosPendentes);
r.get('/admin/relatorio-pedidos', adminOnly, getRelatorioPedidos);
r.put('/admin/anuncios/:id/moderar', adminOnly, moderarAnuncio);
r.put('/admin/usuarios/:id/moderar', adminOnly, moderarUsuario);
r.put('/admin/avaliacoes/:id/moderar', adminOnly, moderarAvaliacao);
r.get('/admin/relatorios', adminOnly, relatorios);
r.get('/admin/denuncias', adminOnly, getDenunciasPendentes);
r.put('/admin/denuncias/:id/resolver', adminOnly, resolverDenuncia);

export default r;