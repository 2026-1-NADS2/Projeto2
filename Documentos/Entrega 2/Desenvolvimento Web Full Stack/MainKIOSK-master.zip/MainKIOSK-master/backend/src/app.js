import express from 'express'
import cors from 'cors'
import routes from './routes.js'
import path from 'path'
import {fileURLToPath} from 'url'
import {dirname} from 'path'

const app = express()
app.use(cors())
app.use(express.json())

const __filename = fileURLToPath(import.meta.url)
const __dirname = dirname(__filename)

app.use('/uploads', express.static(path.join(__dirname, '../uploads')))
app.use('/', express.static(path.join(__dirname, '../../frontend')))
app.get('/', (req, res) => res.redirect('/index.html'))
app.use('/api', routes)

export default app