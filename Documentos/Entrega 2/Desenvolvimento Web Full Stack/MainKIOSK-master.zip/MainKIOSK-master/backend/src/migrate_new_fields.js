import 'dotenv/config';
import pg from 'pg';

const { Pool } = pg;

const pgPool = new Pool({
    connectionString: process.env.DATABASE_URL,
    ssl: {
        rejectUnauthorized: false
    }
});

async function migrate() {
    try {
        console.log('Iniciando migração...');
        
        // Adicionar telefone à tabela usuarios (se não existir)
        await pgPool.query(`
            ALTER TABLE usuarios 
            ADD COLUMN IF NOT EXISTS telefone VARCHAR(20)
        `);
        console.log('Coluna "telefone" verificada/adicionada em "usuarios".');

        // Adicionar link_externo à tabela anuncios (se não existir)
        await pgPool.query(`
            ALTER TABLE anuncios 
            ADD COLUMN IF NOT EXISTS link_externo TEXT
        `);
        console.log('Coluna "link_externo" verificada/adicionada em "anuncios".');

        console.log('Migração concluída com sucesso!');
    } catch (err) {
        console.error('Erro na migração:', err);
    } finally {
        await pgPool.end();
    }
}

migrate();
