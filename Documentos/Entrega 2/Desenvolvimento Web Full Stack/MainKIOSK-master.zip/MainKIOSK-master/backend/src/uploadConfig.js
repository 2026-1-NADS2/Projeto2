import multer from 'multer';

// Usamos memoryStorage para que os arquivos fiquem na RAM e possam ser enviados ao Neon como Base64
const storage = multer.memoryStorage();

const upload = multer({ 
    storage,
    limits: { fileSize: 20 * 1024 * 1024 }, // limite de 20MB
    fileFilter: (req, file, cb) => {
        const allowedMimes = [
            'image/jpeg',
            'image/pjpeg',
            'image/png',
            'image/webp'
        ];

        if (allowedMimes.includes(file.mimetype)) {
            cb(null, true);
        } else {
            cb(new Error('Tipo de arquivo inválido. Apenas imagens são permitidas.'));
        }
    }
});

export default upload;