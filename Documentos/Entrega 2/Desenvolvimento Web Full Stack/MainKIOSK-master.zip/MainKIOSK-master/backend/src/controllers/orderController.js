import { pool } from '../db.js';

export async function createOrder(req, res) {
    const id_lojista = req.user.id;
    const { id_fornecedor, id_endereco_entrega, itens, observacoes } = req.body;

    if (id_lojista === parseInt(id_fornecedor)) {
        return res.status(403).json({ error: 'Você não pode comprar seus próprios produtos.' });
    }

    const conn = await pool.getConnection();
    try {
        await conn.beginTransaction();

        let valor_total = 0;
        for (const item of itens) {
            const [anuncio] = await conn.query_mysql('SELECT preco_unitario, estoque FROM anuncios WHERE id_anuncio = ?', [item.id_anuncio]);
            if (anuncio.length === 0) throw new Error(`Anúncio ${item.id_anuncio} não encontrado.`);
            if (anuncio[0].estoque < item.quantidade) throw new Error(`Estoque insuficiente para o item ${item.id_anuncio}.`);
            
            // Se o item já vier com preço (negociado), usamos ele. Senão, usamos o do anúncio.
            const preco = item.preco_unitario || anuncio[0].preco_unitario;
            valor_total += preco * item.quantidade;
            item.preco_unitario = preco;
        }

        const [orderResult] = await conn.query_mysql(
            `INSERT INTO pedidos (id_lojista, id_fornecedor, id_endereco_entrega, valor_total, observacoes) 
             VALUES (?, ?, ?, ?, ?) RETURNING id_pedido`,
            [id_lojista, id_fornecedor, id_endereco_entrega || null, valor_total, observacoes]
        );
        const id_pedido = orderResult[0].id_pedido;

        for (const item of itens) {
            await conn.query_mysql(
                'INSERT INTO itens_pedido (id_pedido, id_anuncio, quantidade, preco_unitario) VALUES (?, ?, ?, ?)',
                [id_pedido, item.id_anuncio, item.quantidade, item.preco_unitario]
            );
            await conn.query_mysql(
                'UPDATE anuncios SET estoque = estoque - ? WHERE id_anuncio = ?',
                [item.quantidade, item.id_anuncio]
            );
        }

        await conn.commit();
        res.status(201).json({ message: 'Pedido realizado com sucesso!', id_pedido });
    } catch (err) {
        await conn.rollback();
        res.status(500).json({ error: err.message || 'Erro ao realizar pedido.' });
    } finally {
        conn.release_mysql();
    }
}

export async function getOrders(req, res) {
    const id_usuario = req.user.id;
    try {
        let sql = `
            SELECT p.*, u.nome_fantasia as parceiro, u.email as email_parceiro
            FROM pedidos p
            JOIN usuarios u ON (p.id_fornecedor = u.id OR p.id_lojista = u.id)
            WHERE (p.id_lojista = ? OR p.id_fornecedor = ?) AND u.id != ?
            ORDER BY p.criado_em DESC
        `;
        const [rows] = await pool.query_mysql(sql, [id_usuario, id_usuario, id_usuario]);
        res.json(rows);
    } catch (err) {
        res.status(500).json({ error: 'Erro ao buscar pedidos.' });
    }
}

export async function updateOrderStatus(req, res) {
    const { id } = req.params;
    const { status } = req.body;
    const id_usuario = req.user.id;

    try {
        const [pedido] = await pool.query_mysql('SELECT * FROM pedidos WHERE id_pedido = ?', [id]);
        if (pedido.length === 0) return res.status(404).json({ error: 'Pedido não encontrado.' });

        const isFornecedor = pedido[0].id_fornecedor === id_usuario;
        const isLojista = pedido[0].id_lojista === id_usuario;

        if (!isFornecedor && !isLojista) return res.status(403).json({ error: 'Sem permissão.' });

        await pool.query_mysql('UPDATE pedidos SET status = ? WHERE id_pedido = ?', [status, id]);
        res.json({ message: 'Status do pedido atualizado.' });
    } catch (err) {
        res.status(500).json({ error: 'Erro ao atualizar status.' });
    }
}
