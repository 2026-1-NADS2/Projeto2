import { pool } from '../db.js';

// Helpers para log
async function auditLog(id_admin, acao, detalhes) {
    await pool.query_mysql(
        'INSERT INTO logs_auditoria (id_admin, acao, detalhes) VALUES (?, ?, ?)',
        [id_admin, acao, detalhes]
    );
}

// Admin: Aprovar/Reprovar Anúncio
export async function moderarAnuncio(req, res) {
    const id_admin = req.user.id;
    const { id } = req.params;
    const { acao, motivo } = req.body; // acao: 'APROVAR' ou 'REPROVAR'

    if (!['APROVAR', 'REPROVAR'].includes(acao)) {
        return res.status(400).json({ error: 'Ação inválida.' });
    }

    const novoStatus = acao === 'APROVAR' ? 'ATIVO' : 'REPROVADO';

    try {
        await pool.query_mysql(
            'UPDATE anuncios SET status = ?, motivo_reprovacao = ? WHERE id_anuncio = ?',
            [novoStatus, motivo || null, id]
        );

        await auditLog(id_admin, `Anúncio ${id} ${novoStatus}`, motivo || '');
        res.json({ message: `Anúncio ${novoStatus.toLowerCase()} com sucesso.` });
    } catch {
        res.status(500).json({ error: 'Erro ao moderar anúncio.' });
    }
}

// Admin: Listar Anúncios Pendentes
export async function getAnunciosPendentes(req, res) {
    try {
        const [rows] = await pool.query_mysql(`
            SELECT a.*, u.nome_fantasia as fornecedor, u.razao_social,
            (SELECT dados_imagem FROM imagens_anuncio WHERE id_anuncio = a.id_anuncio LIMIT 1) as imagem_principal
            FROM anuncios a 
            JOIN usuarios u ON a.id_usuario = u.id 
            WHERE a.status = 'PENDENTE'
            ORDER BY a.criado_em ASC
        `);
        res.json(rows);
    } catch (err) {
        console.error('Erro em getAnunciosPendentes:', err);
        res.status(500).json({ error: 'Erro ao buscar anúncios pendentes.' });
    }
}

// Admin: Bloquear/Desbloquear Usuário
export async function moderarUsuario(req, res) {
    const id_admin = req.user.id;
    const { id } = req.params;
    const { bloquear } = req.body; // boolean

    const novoStatus = bloquear ? 'BLOQUEADO' : 'ATIVO';

    try {
        await pool.query_mysql('UPDATE usuarios SET status = ? WHERE id = ?', [novoStatus, id]);
        await auditLog(id_admin, `Usuário ${id} ${novoStatus}`, '');
        res.json({ message: `Usuário ${novoStatus.toLowerCase()} com sucesso.` });
    } catch {
        res.status(500).json({ error: 'Erro ao moderar usuário.' });
    }
}

// Admin: Ocultar/Exibir Avaliação
export async function moderarAvaliacao(req, res) {
    const id_admin = req.user.id;
    const { id } = req.params;
    const { ocultar } = req.body; // boolean

    try {
        await pool.query_mysql('UPDATE avaliacoes SET oculto = ? WHERE id_avaliacao = ?', [ocultar, id]);
        await auditLog(id_admin, `Avaliação ${id} ${ocultar ? 'ocultada' : 'exibida'}`, '');
        res.json({ message: `Avaliação ${ocultar ? 'ocultada' : 'exibida'} com sucesso.` });
    } catch {
        res.status(500).json({ error: 'Erro ao moderar avaliação.' });
    }
}

// Admin: Relatórios Simples
export async function relatorios(req, res) {
    try {
        // Cadastros totais por perfil
        const [usuarios] = await pool.query_mysql('SELECT perfil, COUNT(*) as total FROM usuarios GROUP BY perfil');
        
        // Anúncios por status
        const [anuncios] = await pool.query_mysql('SELECT status, COUNT(*) as total FROM anuncios GROUP BY status');

        // Logs recentes
        const [logs] = await pool.query_mysql('SELECT * FROM logs_auditoria ORDER BY criado_em DESC LIMIT 20');

        res.json({
            cadastros: usuarios,
            anuncios: anuncios,
            ultimas_acoes: logs
        });
    } catch {
        res.status(500).json({ error: 'Erro ao gerar relatórios.' });
    }
}

// Admin: Relatório de Pedidos (View do PDF Entrega 2)
export async function getRelatorioPedidos(req, res) {
    try {
        const [rows] = await pool.query_mysql('SELECT * FROM vw_relatorio_pedidos ORDER BY data_pedido DESC');
        res.json(rows);
    } catch (err) {
        console.error('Erro em getRelatorioPedidos:', err);
        res.status(500).json({ error: 'Erro ao buscar relatório de pedidos.' });
    }
}

// Admin: Listar Denúncias Pendentes
export async function getDenunciasPendentes(req, res) {
    try {
        const [rows] = await pool.query_mysql(`
            SELECT d.id_denuncia, d.motivo, d.descricao, d.criado_em,
                   a.id_anuncio, a.titulo as anuncio_titulo,
                   uf.id as id_fornecedor, uf.nome_fantasia as fornecedor_nome,
                   uc.nome_fantasia as denunciante_nome
            FROM denuncias d
            JOIN anuncios a ON d.id_anuncio = a.id_anuncio
            JOIN usuarios uf ON a.id_usuario = uf.id
            JOIN usuarios uc ON d.id_usuario_denunciante = uc.id
            WHERE d.status = 'PENDENTE'
            ORDER BY d.criado_em ASC
        `);
        res.json(rows);
    } catch (err) {
        console.error('Erro em getDenunciasPendentes:', err);
        res.status(500).json({ error: 'Erro ao buscar denúncias pendentes.' });
    }
}

// Admin: Resolver Denúncia
export async function resolverDenuncia(req, res) {
    const id_admin = req.user.id;
    const { id } = req.params; // id_denuncia
    const { acao } = req.body; // 'REJEITAR', 'APAGAR_ANUNCIO', 'BANIR_FORNECEDOR'

    try {
        const [denuncia] = await pool.query_mysql('SELECT * FROM denuncias WHERE id_denuncia = ?', [id]);
        if (denuncia.length === 0) return res.status(404).json({ error: 'Denúncia não encontrada.' });
        
        const d = denuncia[0];

        if (acao === 'REJEITAR') {
            await pool.query_mysql("UPDATE denuncias SET status = 'REJEITADA' WHERE id_denuncia = ?", [id]);
            await auditLog(id_admin, `Denúncia ${id} Rejeitada`, `Anúncio: ${d.id_anuncio}`);
            return res.json({ message: 'Denúncia rejeitada com sucesso.' });
        } 
        
        if (acao === 'APAGAR_ANUNCIO') {
            await pool.query_mysql("UPDATE anuncios SET status = 'REPROVADO', motivo_reprovacao = 'Removido por denúncia' WHERE id_anuncio = ?", [d.id_anuncio]);
            await pool.query_mysql("UPDATE denuncias SET status = 'ACEITA' WHERE id_denuncia = ?", [id]);
            await auditLog(id_admin, `Anúncio ${d.id_anuncio} Reprovado via Denúncia`, `Denúncia ID: ${id}`);
            return res.json({ message: 'Anúncio removido e denúncia aceita.' });
        }

        if (acao === 'BANIR_FORNECEDOR') {
            const [anuncio] = await pool.query_mysql('SELECT id_usuario FROM anuncios WHERE id_anuncio = ?', [d.id_anuncio]);
            if(anuncio.length > 0) {
                const id_fornecedor = anuncio[0].id_usuario;
                await pool.query_mysql("UPDATE usuarios SET status = 'BLOQUEADO' WHERE id = ?", [id_fornecedor]);
                await pool.query_mysql("UPDATE anuncios SET status = 'REPROVADO' WHERE id_usuario = ?", [id_fornecedor]);
                await pool.query_mysql("UPDATE denuncias SET status = 'ACEITA' WHERE id_denuncia = ?", [id]);
                await auditLog(id_admin, `Fornecedor ${id_fornecedor} Banido via Denúncia`, `Denúncia ID: ${id}`);
                return res.json({ message: 'Fornecedor banido, anúncios reprovados e denúncia aceita.' });
            }
        }

        return res.status(400).json({ error: 'Ação inválida.' });
    } catch (err) {
        console.error('Erro ao resolver denúncia:', err);
        res.status(500).json({ error: 'Erro ao resolver denúncia.' });
    }
}