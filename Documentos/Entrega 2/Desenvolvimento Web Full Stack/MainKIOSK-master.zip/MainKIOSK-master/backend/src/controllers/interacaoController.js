import { pool } from '../db.js';

// ---- AVALIAÇÕES ----

// Comprador: Avaliar anúncio/fornecedor
export async function createAvaliacao(req, res) {
    const id_comprador = req.user.id;
    const { id_anuncio, id_fornecedor, nota, comentario } = req.body;

    if (!nota || nota < 1 || nota > 5) {
        return res.status(400).json({ error: 'A nota deve ser entre 1 e 5.' });
    }

    if (!id_anuncio && !id_fornecedor) {
        return res.status(400).json({ error: 'É necessário informar o anúncio ou o fornecedor a ser avaliado.' });
    }

    try {
        // Verificar limite de 1 avaliação por anúncio por comprador
        if (id_anuncio) {
            const [existente] = await pool.query_mysql(
                'SELECT id_avaliacao FROM avaliacoes WHERE id_comprador = ? AND id_anuncio = ?',
                [id_comprador, id_anuncio]
            );
            if (existente.length > 0) {
                return res.status(403).json({ error: 'Você já avaliou este anúncio.' });
            }
        }

        await pool.query_mysql(
            'INSERT INTO avaliacoes (id_comprador, id_anuncio, id_fornecedor, nota, comentario) VALUES (?, ?, ?, ?, ?)',
            [id_comprador, id_anuncio || null, id_fornecedor || null, nota, comentario]
        );

        res.status(201).json({ message: 'Avaliação registrada com sucesso.' });
    } catch (err) {
        res.status(500).json({ error: 'Erro ao registrar avaliação.' });
    }
}

// Geral: Listar avaliações de um anúncio
export async function getAvaliacoesAnuncio(req, res) {
    const { id_anuncio } = req.params;
    try {
        const [avaliacoes] = await pool.query_mysql(
            `SELECT av.id_avaliacao, av.nota, av.comentario, av.criado_em, u.nome_fantasia as comprador 
             FROM avaliacoes av
             JOIN usuarios u ON av.id_comprador = u.id
             WHERE av.id_anuncio = ? AND av.oculto = FALSE
             ORDER BY av.criado_em DESC`,
            [id_anuncio]
        );
        res.json(avaliacoes);
    } catch {
        res.status(500).json({ error: 'Erro ao listar avaliações.' });
    }
}


// ---- FAVORITOS ----

// Comprador: Favoritar
export async function toggleFavorito(req, res) {
    const id_comprador = req.user.id;
    const { id_anuncio, id_fornecedor } = req.body;

    if (!id_anuncio && !id_fornecedor) {
        return res.status(400).json({ error: 'Informe id_anuncio ou id_fornecedor.' });
    }

    try {
        const [existente] = await pool.query_mysql(
            'SELECT id_favorito FROM favoritos WHERE id_comprador = ? AND (id_anuncio = ? OR id_fornecedor = ?)',
            [id_comprador, id_anuncio || null, id_fornecedor || null]
        );

        if (existente.length > 0) {
            // Remover dos favoritos
            await pool.query_mysql('DELETE FROM favoritos WHERE id_favorito = ?', [existente[0].id_favorito]);
            return res.json({ message: 'Removido dos favoritos.' });
        } else {
            // Adicionar aos favoritos
            await pool.query_mysql(
                'INSERT INTO favoritos (id_comprador, id_anuncio, id_fornecedor) VALUES (?, ?, ?)',
                [id_comprador, id_anuncio || null, id_fornecedor || null]
            );
            return res.status(201).json({ message: 'Adicionado aos favoritos.' });
        }
    } catch {
        res.status(500).json({ error: 'Erro ao gerenciar favorito.' });
    }
}

// Comprador: Listar seus favoritos
export async function getMeusFavoritos(req, res) {
    const id_comprador = req.user.id;
    try {
        const [favoritos] = await pool.query_mysql(
            `SELECT f.id_favorito, f.criado_em, 
             a.titulo as anuncio_titulo, u.nome_fantasia as fornecedor_nome
             FROM favoritos f
             LEFT JOIN anuncios a ON f.id_anuncio = a.id_anuncio
             LEFT JOIN usuarios u ON f.id_fornecedor = u.id
             WHERE f.id_comprador = ?
             ORDER BY f.criado_em DESC`,
            [id_comprador]
        );
        res.json(favoritos);
    } catch {
        res.status(500).json({ error: 'Erro ao listar favoritos.' });
    }
}

// ---- DENÚNCIAS ----

// Comprador: Denunciar um anúncio
export async function criarDenuncia(req, res) {
    const id_usuario_denunciante = req.user.id;
    const { id } = req.params; // id_anuncio
    const { motivo, descricao } = req.body;

    if (!motivo) {
        return res.status(400).json({ error: 'O motivo da denúncia é obrigatório.' });
    }

    try {
        await pool.query_mysql(
            'INSERT INTO denuncias (id_anuncio, id_usuario_denunciante, motivo, descricao) VALUES (?, ?, ?, ?)',
            [id, id_usuario_denunciante, motivo, descricao || null]
        );
        res.status(201).json({ message: 'Denúncia enviada com sucesso. Nossa equipe analisará em breve.' });
    } catch (err) {
        console.error('Erro ao criar denúncia:', err);
        res.status(500).json({ error: 'Erro ao registrar denúncia.' });
    }
}