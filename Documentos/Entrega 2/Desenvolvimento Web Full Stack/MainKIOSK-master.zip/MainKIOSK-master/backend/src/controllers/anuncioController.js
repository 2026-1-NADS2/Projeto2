import { pool } from '../db.js';
import fs from 'fs';
import path from 'path';

// Fornecedor: Criar Anúncio
export async function createAnuncio(req, res) {
    const id_usuario = req.user.id;
    const { 
        titulo, descricao, id_categoria, unidade, marca, 
        pedido_minimo, regiao_atendida, prazo_entrega, 
        formas_contato, status, preco_unitario, estoque,
        cep, cidade, estado, logradouro, link_externo 
    } = req.body;
    
    if (!titulo || !formas_contato) {
        return res.status(400).json({ error: 'Título e formas de contato são obrigatórios.' });
    }

    const anuncioStatus = status || 'PENDENTE';

    // Sanitização de campos numéricos para evitar erro 22P02 no Postgres
    const cleanIdCategoria = id_categoria && id_categoria !== '' ? parseInt(id_categoria) : null;
    const cleanPreco = preco_unitario && preco_unitario !== '' ? parseFloat(preco_unitario) : 0;
    const cleanEstoque = estoque && estoque !== '' ? parseInt(estoque) : 0;
    const cleanPedidoMin = pedido_minimo && pedido_minimo !== '' ? parseInt(pedido_minimo) : 1;

    const conn = await pool.getConnection();
    try {
        await conn.beginTransaction();

        const [result] = await conn.query_mysql(
            `INSERT INTO anuncios (
                id_usuario, id_categoria, titulo, descricao, unidade, marca, 
                pedido_minimo, regiao_atendida, prazo_entrega, formas_contato, 
                status, preco_unitario, estoque, cep, cidade, estado, logradouro, link_externo
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?) RETURNING id_anuncio`,
            [
                id_usuario, cleanIdCategoria, titulo, descricao, unidade, marca, 
                cleanPedidoMin, regiao_atendida, prazo_entrega, formas_contato, 
                anuncioStatus, cleanPreco, cleanEstoque, 
                cep, cidade, estado, logradouro, link_externo
            ]
        );

        if (!result || result.length === 0) {
            throw new Error('Falha ao inserir anúncio - Nenhum resultado retornado');
        }

        const id_anuncio = result[0].id_anuncio;

        // Salvar imagens no BANCO (Neon) como Base64
        if (req.files && req.files.length > 0) {
            for (const file of req.files) {
                // Converte o buffer da imagem para string Base64
                const base64Image = `data:${file.mimetype};base64,${file.buffer.toString('base64')}`;
                
                await conn.query_mysql(
                    'INSERT INTO imagens_anuncio (id_anuncio, dados_imagem) VALUES (?, ?)',
                    [id_anuncio, base64Image]
                );
            }
        }

        await conn.commit();
        res.status(201).json({ message: 'Anúncio criado com sucesso!', id_anuncio });
    } catch (err) {
        await conn.rollback();
        console.error('Erro detalhado ao criar anúncio:', err.message);
        if (err.detail) console.error('Detalhe DB:', err.detail);
        res.status(500).json({ error: 'Erro ao criar anúncio no banco de dados. Tente novamente.' });
    } finally {
        conn.release_mysql();
    }
}

// Comprador/Geral: Listar anúncios (com paginação e filtros)
export async function getAnuncios(req, res) {
    try {
        const { pagina = 1, limite = 10, categoria, busca, regiao, moq, id_usuario } = req.query;
        const offset = (parseInt(pagina) - 1) * parseInt(limite);
        
        let query = `
            SELECT a.*, u.nome_fantasia as fornecedor, u.razao_social, u.latitude, u.longitude,
            (SELECT dados_imagem FROM imagens_anuncio WHERE id_anuncio = a.id_anuncio LIMIT 1) as imagem_principal
            FROM anuncios a 
            JOIN usuarios u ON a.id_usuario = u.id 
            WHERE a.status = 'ATIVO'
        `;
        const params = [];

        if (id_usuario) {
            query += ` AND a.id_usuario = ?`;
            params.push(parseInt(id_usuario));
        }
        if (categoria && categoria !== '') {
            if (!isNaN(categoria)) {
                query += ` AND a.id_categoria = ?`;
                params.push(parseInt(categoria));
            } else {
                // Filtro por NOME da categoria (requer join ou subquery)
                query += ` AND a.id_categoria IN (SELECT id_categoria FROM categorias WHERE nome = ?)`;
                params.push(categoria);
            }
        }
        if (regiao) {
            query += ` AND (a.regiao_atendida ILIKE ? OR a.cidade ILIKE ?)`;
            params.push(`%${regiao}%`, `%${regiao}%`);
        }
        if (moq) {
            query += ` AND a.pedido_minimo <= ?`;
            params.push(parseInt(moq));
        }
        if (busca) {
            query += ` AND (unaccent(a.titulo) ILIKE unaccent(?) OR unaccent(a.marca) ILIKE unaccent(?) OR unaccent(u.nome_fantasia) ILIKE unaccent(?))`;
            const b = `%${busca}%`;
            params.push(b, b, b);
        }

        query += ` ORDER BY a.criado_em DESC LIMIT ? OFFSET ?`;
        params.push(parseInt(limite), offset);

        const [rows] = await pool.query_mysql(query, params);
        res.json(rows);
    } catch (err) {
        console.error('Erro em getAnuncios:', err);
        res.status(500).json({ error: 'Erro ao buscar anúncios.' });
    }
}

// Geral: Detalhes de um anúncio
export async function getAnuncioById(req, res) {
    const { id } = req.params;
    try {
        const [anuncios] = await pool.query_mysql(
            `SELECT a.*, u.nome_fantasia, u.razao_social, u.email, u.telefone, u.latitude, u.longitude 
             FROM anuncios a 
             JOIN usuarios u ON a.id_usuario = u.id 
             WHERE a.id_anuncio = ?`,
            [id]
        );

        if (anuncios.length === 0) return res.status(404).json({ error: 'Anúncio não encontrado.' });

        const [imagens] = await pool.query_mysql('SELECT dados_imagem FROM imagens_anuncio WHERE id_anuncio = ?', [id]);
        
        const anuncio = anuncios[0];
        anuncio.imagens = imagens.map(i => i.dados_imagem);

        res.json(anuncio);
    } catch (err) {
        res.status(500).json({ error: 'Erro ao buscar detalhes do anúncio.' });
    }
}

// Fornecedor: Listar seus próprios anúncios
export async function getMeusAnuncios(req, res) {
    const id_usuario = req.user.id;
    try {
        const sql = `
            SELECT a.*, 
            (SELECT dados_imagem FROM imagens_anuncio WHERE id_anuncio = a.id_anuncio LIMIT 1) as imagem_principal
            FROM anuncios a 
            WHERE a.id_usuario = ? 
            ORDER BY a.criado_em DESC
        `;
        const [rows] = await pool.query_mysql(sql, [id_usuario]);
        res.json(rows);
    } catch {
        res.status(500).json({ error: 'Erro ao listar seus anúncios.' });
    }
}

// Fornecedor: Atualizar Anúncio
export async function updateAnuncio(req, res) {
    const id_usuario = req.user.id;
    const { id } = req.params;
    const { 
        titulo, descricao, id_categoria, unidade, marca, 
        pedido_minimo, regiao_atendida, prazo_entrega, 
        formas_contato, status, preco_unitario, estoque,
        cep, cidade, estado, logradouro, link_externo 
    } = req.body;

    try {
        const [existente] = await pool.query_mysql('SELECT * FROM anuncios WHERE id_anuncio = ? AND id_usuario = ?', [id, id_usuario]);
        if (existente.length === 0) return res.status(404).json({ error: 'Anúncio não encontrado ou sem permissão.' });

        const updates = [];
        const params = [];

        if (titulo) { updates.push('titulo=?'); params.push(titulo); }
        if (descricao) { updates.push('descricao=?'); params.push(descricao); }
        if (id_categoria) { updates.push('id_categoria=?'); params.push(parseInt(id_categoria)); }
        if (unidade) { updates.push('unidade=?'); params.push(unidade); }
        if (marca) { updates.push('marca=?'); params.push(marca); }
        if (pedido_minimo !== undefined && pedido_minimo !== '') { updates.push('pedido_minimo=?'); params.push(parseInt(pedido_minimo)); }
        if (regiao_atendida) { updates.push('regiao_atendida=?'); params.push(regiao_atendida); }
        if (prazo_entrega) { updates.push('prazo_entrega=?'); params.push(prazo_entrega); }
        if (formas_contato) { updates.push('formas_contato=?'); params.push(formas_contato); }
        if (status) { updates.push('status=?'); params.push(status); }
        if (preco_unitario !== undefined && preco_unitario !== '') { updates.push('preco_unitario=?'); params.push(parseFloat(preco_unitario)); }
        if (estoque !== undefined && estoque !== '') { updates.push('estoque=?'); params.push(parseInt(estoque)); }
        if (cep) { updates.push('cep=?'); params.push(cep); }
        if (cidade) { updates.push('cidade=?'); params.push(cidade); }
        if (estado) { updates.push('estado=?'); params.push(estado); }
        if (logradouro) { updates.push('logradouro=?'); params.push(logradouro); }
        if (link_externo !== undefined) { updates.push('link_externo=?'); params.push(link_externo); }

        if (updates.length > 0) {
            params.push(id);
            await pool.query_mysql(`UPDATE anuncios SET ${updates.join(', ')} WHERE id_anuncio=?`, params);
        }

        // Se houver novas imagens, adicionar como Base64
        if (req.files && req.files.length > 0) {
            for (const file of req.files) {
                const base64Image = `data:${file.mimetype};base64,${file.buffer.toString('base64')}`;
                await pool.query_mysql('INSERT INTO imagens_anuncio (id_anuncio, dados_imagem) VALUES (?, ?)', [id, base64Image]);
            }
        }

        res.json({ message: 'Anúncio atualizado com sucesso.' });
    } catch (err) {
        console.error('Erro ao atualizar anúncio:', err);
        res.status(500).json({ error: 'Erro ao atualizar anúncio.' });
    }
}

// Fornecedor: Deletar Anúncio
export async function deleteAnuncio(req, res) {
    const id_usuario = req.user.id;
    const { id } = req.params;

    const conn = await pool.getConnection();
    try {
        await conn.beginTransaction();

        const [existente] = await conn.query_mysql('SELECT * FROM anuncios WHERE id_anuncio = ? AND id_usuario = ?', [id, id_usuario]);
        if (existente.length === 0) return res.status(404).json({ error: 'Anúncio não encontrado ou permissão negada.' });

        await conn.query_mysql('DELETE FROM anuncios WHERE id_anuncio = ?', [id]); 

        await conn.commit();
        res.json({ message: 'Anúncio removido com sucesso.' });
    } catch {
        await conn.rollback();
        res.status(500).json({ error: 'Erro ao deletar anúncio.' });
    } finally {
        conn.release_mysql();
    }
}