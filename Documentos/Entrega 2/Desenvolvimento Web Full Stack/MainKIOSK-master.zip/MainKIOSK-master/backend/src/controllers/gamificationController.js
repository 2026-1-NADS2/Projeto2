import { pool } from '../db.js';

export async function getMeusSelos(req, res) {
    const id_usuario = req.user.id;
    try {
        const [rows] = await pool.query_mysql(
            `SELECT cs.data_conquista, s.nome_selo, s.descricao_selo, s.icone_selo 
             FROM conquistas_selos cs
             JOIN selos s ON cs.id_selo = s.id_selo
             WHERE cs.id_usuario = ?`,
            [id_usuario]
        );
        res.json(rows);
    } catch (err) {
        res.status(500).json({ error: 'Erro ao buscar selos.' });
    }
}

export async function grantSelo(id_usuario, id_selo) {
    try {
        await pool.query_mysql(
            'INSERT IGNORE INTO conquistas_selos (id_usuario, id_selo) VALUES (?, ?)',
            [id_usuario, id_selo]
        );
        return true;
    } catch (err) {
        console.error('Erro ao conceder selo:', err);
        return false;
    }
}
