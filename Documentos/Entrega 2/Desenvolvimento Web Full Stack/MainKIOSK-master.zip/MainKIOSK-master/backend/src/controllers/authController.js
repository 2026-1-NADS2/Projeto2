import {pool} from '../db.js'
import bcrypt from 'bcrypt'
import { createToken, denyToken} from '../services/tokenService.js'

const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
const sanitizaUser = (u)=> ({
    id: u.id, razao_social: u.razao_social, email: u.email, perfil: u.perfil
})

//Register
export async function register(req, res) {
    const {razao_social, cnpj, email, senha, perfil, telefone} = req.body
    if (!razao_social || !cnpj || !email || !senha)
        return res.status(400).json({error: 'Razão social, CNPJ, email e senha são obrigatórios'})
    
    if(!emailRegex.test(email))
        return res.status(400).json({error: 'E-mail Inválido'})

    const userPerfil = perfil || 'AMBOS'

    try{
        const hash = await bcrypt.hash(senha, 10)
        const [result] = await pool.query_mysql(
            'INSERT INTO usuarios (razao_social, cnpj, email, senha, perfil, telefone) VALUES (?, ?, ?, ?, ?, ?) RETURNING id', 
            [razao_social, cnpj, email, hash, userPerfil, telefone]
        )
        res.status(201).json({id: result[0].id, razao_social, cnpj, email, perfil: userPerfil, telefone})
    } catch (err) {
        if (err.code === '23505') { // UNIQUE VIOLATION no Postgres
            const detail = err.detail || '';
            if (detail.includes('email')) {
                return res.status(409).json({ error: 'Este e-mail já está cadastrado.' });
            } else if (detail.includes('cnpj')) {
                return res.status(409).json({ error: 'Este CNPJ já possui uma conta.' });
            }
            return res.status(409).json({ error: 'E-mail ou CNPJ já cadastrado.' });
        }
        console.error('Erro no registro:', err);
        res.status(500).json({ error: 'Erro ao realizar cadastro.' });
    }
}

//Login
export async function login(req, res) {
    const {email, senha} = req.body
    if (!email || !senha)
        return res.status(400).json({error: 'Email e senha são obrigatórios'})


    try{
        const [rows]= await pool.query_mysql(
            'SELECT * FROM usuarios WHERE email = ?', [email]
        )
        if(!rows.length)
            return res.status(401).json({error: 'Credenciais Inválidas'})
        
        const user = rows[0]
        
        if(user.status === 'BLOQUEADO')
            return res.status(403).json({error: 'Usuário bloqueado pelo administrador'})

        const match = await bcrypt.compare(senha, user.senha)
        if(!match)
            return res.status(401).json({error: 'Credenciais Inválidas'})
            
        const {token} = createToken({id: user.id, perfil: user.perfil})
        res.json({token, user: sanitizaUser(user)})
    } catch (err) {
        console.error('Erro no login:', err);
        return res.status(500).json({error: 'Erro no Login'})
    } 
}

//Logout
export async function logout(req, res) {
    try{
        denyToken(req.user.jti)
        res.json({message: 'Logout Realizado com sucesso'})
    } catch {
        res.status(500).json({error: 'Erro no Logout'})
    }
}

//ForgotPassword
export async function forgotPassword(req, res) {
    const {email, telefone, novaSenha} = req.body
    if (!email || !telefone || !novaSenha)
        return res.status(400).json({error: 'Email, telefone e nova senha são obrigatórios'})
    try{
        // Verifica se e-mail e telefone batem (limpando caracteres não-numéricos do telefone)
        const cleanTelefone = telefone.replace(/\D/g, '');
        
        const [rows] = await pool.query_mysql(
            `SELECT id FROM usuarios 
             WHERE email = ? 
             AND REGEXP_REPLACE(telefone, '[^0-9]', '', 'g') = ?`,
            [email, cleanTelefone]
        )

        if (rows.length === 0) {
            return res.status(404).json({error: 'E-mail ou telefone não correspondem ao cadastro.'})
        }

        const hash = await bcrypt.hash(novaSenha, 10)
        await pool.query_mysql(
            'UPDATE usuarios SET senha = ? WHERE id = ?', 
            [hash, rows[0].id]
        )
        res.json({message: 'Senha redefinida com sucesso!'})
    } catch (err) {
        console.error('Erro ao redefinir senha:', err);
        res.status(500).json({error: 'Erro ao redefinir a senha'})
    } 
}