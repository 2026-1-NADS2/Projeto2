import https from 'https';
import { pool } from '../db.js';

export async function consultarCNPJ(req, res) {
    const { cnpj } = req.params;
    
    // Remove caracteres não numéricos
    const cleanCnpj = cnpj.replace(/\D/g, '');

    if (cleanCnpj.length !== 14) {
        return res.status(400).json({ error: 'CNPJ inválido. Deve conter 14 dígitos.' });
    }

    const url = `https://www.receitaws.com.br/v1/cnpj/${cleanCnpj}`;

    https.get(url, (response) => {
        let data = '';

        response.on('data', (chunk) => {
            data += chunk;
        });

        response.on('end', () => {
            try {
                const parsedData = JSON.parse(data);
                
                if (parsedData.status === 'ERROR') {
                    return res.status(404).json({ error: parsedData.message || 'CNPJ não encontrado' });
                }

                // Retornar os dados formatados
                res.json({
                    razao_social: parsedData.nome,
                    nome_fantasia: parsedData.fantasia,
                    cnpj: parsedData.cnpj,
                    email: parsedData.email,
                    telefone: parsedData.telefone,
                    cep: parsedData.cep,
                    estado: parsedData.uf,
                    cidade: parsedData.municipio,
                    situacao: parsedData.situacao
                });
            } catch (error) {
                res.status(500).json({ error: 'Erro ao processar os dados da Receita Federal' });
            }
        });
    }).on('error', (err) => {
        res.status(500).json({ error: 'Erro na comunicação com a API de CNPJ' });
    });
}

export async function getCategorias(req, res) {
    try {
        const [rows] = await pool.query_mysql('SELECT * FROM categorias ORDER BY nome ASC');
        res.json(rows);
    } catch (err) {
        res.status(500).json({ error: 'Erro ao buscar categorias.' });
    }
}