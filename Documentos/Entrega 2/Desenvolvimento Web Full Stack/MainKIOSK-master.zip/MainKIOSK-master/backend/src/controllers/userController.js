import { pool } from '../db.js';
import bcrypt from 'bcrypt';
import fs from 'fs';

// Listar todos os usuários (Pública ou Admin)
export async function getUsuarios(req, res) {
    try {
        const [rows] = await pool.query_mysql(
            'SELECT id, razao_social, nome_fantasia, cnpj, email, telefone, descricao, cidade, estado, cep, perfil, status, criado_em, avatar, banner, site, latitude, longitude FROM usuarios ORDER BY id DESC'
        );
        res.json(rows);
    } catch {
        res.status(500).json({ error: 'Erro ao listar usuários' });
    }
}

// Listar apenas Fornecedores para geolocalização
export async function getFornecedores(req, res) {
    try {
        const [rows] = await pool.query_mysql(
            "SELECT id, razao_social, nome_fantasia, descricao, cidade, estado, latitude, longitude FROM usuarios WHERE perfil IN ('FORNECEDOR', 'AMBOS') AND status = 'ATIVO' ORDER BY nome_fantasia ASC"
        );
        res.json(rows);
    } catch {
        res.status(500).json({ error: 'Erro ao buscar fornecedores' });
    }
}

// Buscar Usuário por ID
export async function getUsuarioById(req, res) {
    const { id } = req.params;
    try {
        const [rows] = await pool.query_mysql(
            'SELECT id, razao_social, nome_fantasia, cnpj, email, telefone, descricao, cidade, estado, cep, perfil, status, criado_em, avatar, banner, site FROM usuarios WHERE id = ?',
            [id]
        );
        if (rows.length === 0) {
            return res.status(404).json({ error: 'Usuário não encontrado' });
        }
        res.json(rows[0]);
    } catch {
        res.status(500).json({ error: 'Erro ao buscar usuário' });
    }
}

// Atualizar Usuário Logado (Me)
export async function updateMe(req, res) {
    const { razao_social, nome_fantasia, telefone, descricao, cidade, estado, cep, currentPassword, newPassword, avatar, banner, site } = req.body;
    const userId = req.user.id;

    try {
        const [rows] = await pool.query_mysql('SELECT * FROM usuarios WHERE id=?', [userId]);
        if (!rows.length) return res.status(404).json({ error: 'Usuário não encontrado' });
        
        const user = rows[0];
        const updates = [];
        const params = [];

        if (razao_social) { updates.push('razao_social=?'); params.push(razao_social); }
        if (nome_fantasia) { updates.push('nome_fantasia=?'); params.push(nome_fantasia); }
        if (telefone) { updates.push('telefone=?'); params.push(telefone); }
        if (descricao) { updates.push('descricao=?'); params.push(descricao); }
        if (cidade) { updates.push('cidade=?'); params.push(cidade); }
        if (estado) { updates.push('estado=?'); params.push(estado); }
        if (cep) { updates.push('cep=?'); params.push(cep); }
        if (avatar) { updates.push('avatar=?'); params.push(avatar); }
        if (banner) { updates.push('banner=?'); params.push(banner); }
        if (site) { updates.push('site=?'); params.push(site); }

        if (newPassword) {
            if (!currentPassword) return res.status(400).json({ error: 'Insira sua senha atual para realizar a troca de senha' });
            const match = await bcrypt.compare(currentPassword, user.senha);
            if (!match) return res.status(401).json({ error: 'Senha atual incorreta' });
            
            const hash = await bcrypt.hash(newPassword, 10);
            updates.push('senha=?');
            params.push(hash);
        }

        if (updates.length === 0) return res.status(400).json({ error: 'Nenhum dado para atualizar' });

        params.push(userId);
        await pool.query_mysql(`UPDATE usuarios SET ${updates.join(', ')} WHERE id=?`, params);
        
        res.json({ message: 'Perfil atualizado com sucesso' });
    } catch {
        res.status(500).json({ error: 'Erro ao atualizar perfil' });
    }
}

// Perfil do Usuário Logado
export async function profile(req, res) {
    try {
        const [rows] = await pool.query_mysql(
            'SELECT id, razao_social, nome_fantasia, cnpj, email, telefone, descricao, cidade, estado, cep, perfil, status, criado_em, avatar, banner, site FROM usuarios WHERE id=?',
            [req.user.id]
        );
        if (!rows.length) return res.status(404).json({ error: 'Usuário não encontrado' });
        res.json(rows[0]);
    } catch {
        res.status(500).json({ error: 'Erro ao buscar perfil' });
    }
}

// Deletar a Própria Conta
export async function deleteMe(req, res) {
    const userId = req.user.id;
    try {
        await pool.query_mysql('DELETE FROM usuarios WHERE id = ?', [userId]);
        res.json({ message: 'Conta deletada com sucesso' });
    } catch {
        res.status(500).json({ error: 'Erro ao excluir usuário' });
    }
}