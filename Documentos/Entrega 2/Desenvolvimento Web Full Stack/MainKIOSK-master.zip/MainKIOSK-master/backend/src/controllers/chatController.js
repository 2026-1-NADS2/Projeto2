import { pool } from '../db.js';

// Criar ou recuperar um chat existente
export async function iniciarChat(req, res) {
    const id_comprador = req.user.id;
    const { id_fornecedor, id_anuncio } = req.body;

    if (!id_fornecedor) return res.status(400).json({ error: 'Fornecedor não especificado.' });

    try {
        let sqlExistente = 'SELECT id_chat FROM chats WHERE id_comprador = ? AND id_fornecedor = ?';
        let paramsExistente = [id_comprador, id_fornecedor];

        if (id_anuncio) {
            sqlExistente += ' AND id_anuncio = ?';
            paramsExistente.push(id_anuncio);
        } else {
            sqlExistente += ' AND id_anuncio IS NULL';
        }

        const [existente] = await pool.query_mysql(sqlExistente, paramsExistente);

        if (existente.length > 0) {
            return res.json({ id_chat: existente[0].id_chat });
        }

        const [result] = await pool.query_mysql(
            'INSERT INTO chats (id_comprador, id_fornecedor, id_anuncio) VALUES (?, ?, ?) RETURNING id_chat',
            [id_comprador, id_fornecedor, id_anuncio || null]
        );

        res.status(201).json({ id_chat: result[0].id_chat });
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: 'Erro ao iniciar chat.' });
    }
}

// Listar todos os chats do usuário (seja ele comprador ou fornecedor)
export async function getMeusChats(req, res) {
    const userId = req.user.id;

    try {
        const [chats] = await pool.query_mysql(
            `SELECT c.id_chat, c.criado_em, c.id_anuncio,
             uc.nome_fantasia as comprador_nome, uc.razao_social as comprador_razao,
             uf.nome_fantasia as fornecedor_nome, uf.razao_social as fornecedor_razao,
             a.titulo as anuncio_titulo, a.preco_unitario as anuncio_preco, a.unidade as anuncio_unidade,
             (SELECT dados_imagem FROM imagens_anuncio WHERE id_anuncio = a.id_anuncio LIMIT 1) as anuncio_imagem
             FROM chats c
             JOIN usuarios uc ON c.id_comprador = uc.id
             JOIN usuarios uf ON c.id_fornecedor = uf.id
             LEFT JOIN anuncios a ON c.id_anuncio = a.id_anuncio
             WHERE c.id_comprador = ? OR c.id_fornecedor = ?
             ORDER BY c.criado_em DESC`,
            [userId, userId]
        );
        res.json(chats);
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: 'Erro ao listar chats.' });
    }
}

// Enviar mensagem
export async function enviarMensagem(req, res) {
    const id_remetente = req.user.id;
    const { id_chat } = req.params;
        const { conteudo, tipo, metadata } = req.body;
    
        if (!conteudo) return res.status(400).json({ error: 'Mensagem vazia.' });
    
        try {
            // Verificar se o usuário faz parte do chat
            const [chat] = await pool.query_mysql('SELECT * FROM chats WHERE id_chat = ?', [id_chat]);
            if (chat.length === 0) return res.status(404).json({ error: 'Chat não encontrado.' });
            if (chat[0].id_comprador !== id_remetente && chat[0].id_fornecedor !== id_remetente) {
                return res.status(403).json({ error: 'Acesso negado ao chat.' });
            }
    
            await pool.query_mysql(
                'INSERT INTO mensagens (id_chat, id_remetente, conteudo, tipo, metadata) VALUES (?, ?, ?, ?, ?)',
                [id_chat, id_remetente, conteudo, tipo || 'TEXTO', metadata ? JSON.stringify(metadata) : null]
            );
    
            res.status(201).json({ message: 'Mensagem enviada.' });
    } catch {
        res.status(500).json({ error: 'Erro ao enviar mensagem.' });
    }
}

// Listar mensagens de um chat
export async function getMensagens(req, res) {
    const userId = req.user.id;
    const { id_chat } = req.params;

    try {
        const [chat] = await pool.query_mysql('SELECT * FROM chats WHERE id_chat = ?', [id_chat]);
        if (chat.length === 0) return res.status(404).json({ error: 'Chat não encontrado.' });
        if (chat[0].id_comprador !== userId && chat[0].id_fornecedor !== userId) {
            return res.status(403).json({ error: 'Acesso negado ao chat.' });
        }

        const [mensagens] = await pool.query_mysql(
            'SELECT * FROM mensagens WHERE id_chat = ? ORDER BY criado_em ASC',
            [id_chat]
        );
        res.json(mensagens);
    } catch {
        res.status(500).json({ error: 'Erro ao listar mensagens.' });
    }
}