import { pool } from '../db.js';

export async function getSupplierStats(req, res) {
    const id_usuario = req.user.id;
    
    try {
        const [ads] = await pool.query_mysql(
            "SELECT COUNT(*) as total FROM anuncios WHERE id_usuario = ? AND status = 'ATIVO'",
            [id_usuario]
        );

        const [chats] = await pool.query_mysql(
            'SELECT COUNT(*) as total FROM chats WHERE id_fornecedor = ?',
            [id_usuario]
        );

        const [sales] = await pool.query_mysql(
            "SELECT SUM(valor_total) as total FROM pedidos WHERE id_fornecedor = ? AND status NOT IN ('AGUARDANDO', 'CANCELADO')",
            [id_usuario]
        );

        const [selos] = await pool.query_mysql(
            'SELECT COUNT(*) as total FROM conquistas_selos WHERE id_usuario = ?',
            [id_usuario]
        );

        res.json({
            anuncios_ativos: ads[0].total,
            chats_ativos: chats[0].total,
            total_vendas: sales[0].total || 0,
            total_selos: selos[0].total
        });
    } catch (err) {
        res.status(500).json({ error: 'Erro ao buscar estatísticas do fornecedor.' });
    }
}

export async function getLojistaStats(req, res) {
    const id_usuario = req.user.id;
    
    try {
        const [pedidos] = await pool.query_mysql(
            'SELECT COUNT(*) as total FROM pedidos WHERE id_lojista = ?',
            [id_usuario]
        );

        const [chats] = await pool.query_mysql(
            'SELECT COUNT(*) as total FROM chats WHERE id_comprador = ?',
            [id_usuario]
        );

        const [spent] = await pool.query_mysql(
            "SELECT SUM(valor_total) as total FROM pedidos WHERE id_lojista = ? AND status != 'CANCELADO'",
            [id_usuario]
        );

        const [selos] = await pool.query_mysql(
            'SELECT COUNT(*) as total FROM conquistas_selos WHERE id_usuario = ?',
            [id_usuario]
        );

        res.json({
            total_pedidos: pedidos[0].total,
            negociacoes_ativas: chats[0].total,
            total_investido: spent[0].total || 0,
            total_selos: selos[0].total
        });
    } catch (err) {
        res.status(500).json({ error: 'Erro ao buscar estatísticas do lojista.' });
    }
}