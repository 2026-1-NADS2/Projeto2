import 'dotenv/config';
import pg from 'pg';

const { Pool } = pg;

const pgPool = new Pool({
    connectionString: process.env.DATABASE_URL,
    ssl: {
        rejectUnauthorized: false
    }
});

async function migrate() {
    try {
        console.log('Criando tabela logs_auditoria...');
        
        await pgPool.query(`
            CREATE TABLE IF NOT EXISTS logs_auditoria (
                id_log SERIAL PRIMARY KEY,
                id_admin INTEGER NOT NULL,
                acao VARCHAR(255) NOT NULL,
                detalhes TEXT,
                criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (id_admin) REFERENCES usuarios(id)
            )
        `);
        console.log('Tabela logs_auditoria criada com sucesso!');

    } catch (err) {
        console.error('Erro na migração:', err);
    } finally {
        await pgPool.end();
    }
}

migrate();
