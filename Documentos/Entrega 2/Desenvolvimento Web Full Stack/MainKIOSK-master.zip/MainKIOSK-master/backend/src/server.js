import 'dotenv/config'
import app from './app.js'
import { createServer } from 'http'
import { Server } from 'socket.io'

const port = process.env.PORT || 3000

// Criar o servidor HTTP puro usando a aplicação Express
const httpServer = createServer(app)

// Acoplar o Socket.io ao servidor HTTP
const io = new Server(httpServer, {
    cors: {
        origin: "*",
        methods: ["GET", "POST"]
    }
})

// Lógica do Chat Real-time
io.on('connection', (socket) => {
    console.log('Usuário conectado:', socket.id)

    socket.on('join_chat', (id_chat) => {
        socket.join(`chat_${id_chat}`)
        console.log(`Socket ${socket.id} entrou na sala: chat_${id_chat}`)
    })

    socket.on('send_message', (data) => {
        // data: { id_chat, id_remetente, conteudo, criado_em }
        io.to(`chat_${data.id_chat}`).emit('receive_message', data)
    })

    socket.on('disconnect', () => {
        console.log('Usuário desconectado:', socket.id)
    })
})

httpServer.listen(port, () => {
    console.log(`Servidor rodando em http://localhost:${port}`)
})