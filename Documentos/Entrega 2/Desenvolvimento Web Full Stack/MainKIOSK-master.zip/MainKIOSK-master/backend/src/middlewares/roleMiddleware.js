export function roleMiddleware(allowedRoles) {
    return async (req, res, next) => {
        try {
            if (!req.user || !req.user.id) {
                return res.status(401).json({ error: 'Acesso negado. Usuário não autenticado.' });
            }

            // Fallback: Se o perfil não estiver no req.user (token antigo ou erro no middleware anterior), 
            // buscamos no banco para garantir.
            if (!req.user.perfil) {
                const { pool } = await import('../db.js');
                const [rows] = await pool.query_mysql('SELECT perfil FROM usuarios WHERE id = ?', [req.user.id]);
                if (rows.length > 0) {
                    req.user.perfil = rows[0].perfil;
                } else {
                    return res.status(401).json({ error: 'Acesso negado. Perfil não encontrado no banco.' });
                }
            }

            const userRole = req.user.perfil;

            // Lógica de Acesso
            let hasAccess = false;
            if (userRole === 'ADMIN') {
                hasAccess = true;
            } else if (allowedRoles.includes(userRole)) {
                hasAccess = true;
            } else if (userRole === 'AMBOS') {
                // Perfil AMBOS sempre tem acesso a rotas de FORNECEDOR ou COMPRADOR
                hasAccess = true;
            }

            if (!hasAccess) {
                return res.status(403).json({ error: `Acesso negado. Seu perfil (${userRole}) não tem permissão.` });
            }

            next();
        } catch (err) {
            console.error('Erro no roleMiddleware:', err);
            return res.status(500).json({ error: 'Erro interno na verificação de permissões.' });
        }
    };
}