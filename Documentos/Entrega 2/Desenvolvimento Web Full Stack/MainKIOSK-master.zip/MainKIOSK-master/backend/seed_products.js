import 'dotenv/config';
import fs from 'fs';
import { pool } from './src/db.js';

const FORNECEDOR_ID = 20;

const categories = [
    { id: 1, name: 'Verduras', image: 'C:\\Users\\davib\\.gemini\\antigravity\\brain\\0688dd13-3cad-4f16-b979-367cc54b789a\\verduras_category_1778427879186.png', products: [
        { titulo: 'Alface Crespa Orgânica', descricao: 'Alface fresca e crocante, cultivada sem agrotóxicos.', unidade: 'Maço', marca: 'Horta Viva', preco: 4.50, estoque: 50, pedido_minimo: 5 },
        { titulo: 'Tomate Cereja Sweet', descricao: 'Tomates pequenos e doces, ideais para saladas.', unidade: 'Bandeja 200g', marca: 'Fazenda Sol', preco: 6.90, estoque: 30, pedido_minimo: 3 },
        { titulo: 'Cenoura Baby', descricao: 'Cenouras pequenas e descascadas, prontas para o consumo.', unidade: 'Pacote 250g', marca: 'VitaTerra', preco: 5.80, estoque: 40, pedido_minimo: 4 }
    ]},
    { id: 2, name: 'Carnes', image: 'C:\\Users\\davib\\.gemini\\antigravity\\brain\\0688dd13-3cad-4f16-b979-367cc54b789a\\carnes_category_1778427892686.png', products: [
        { titulo: 'Picanha Premium Argentina', descricao: 'Corte nobre de picanha, extremamente macia e suculenta.', unidade: 'Kg', marca: 'Black Angus', preco: 89.90, estoque: 15, pedido_minimo: 1 },
        { titulo: 'Filé de Frango Swift', descricao: 'Peito de frango limpo e sem osso, congelado individualmente.', unidade: 'Kg', marca: 'Swift', preco: 24.50, estoque: 100, pedido_minimo: 2 },
        { titulo: 'Costela Suína BBQ', descricao: 'Costela de porco ideal para churrasco ou forno.', unidade: 'Kg', marca: 'Seara', preco: 32.00, estoque: 25, pedido_minimo: 1 }
    ]},
    { id: 3, name: 'Peixes', image: 'C:\\Users\\davib\\.gemini\\antigravity\\brain\\0688dd13-3cad-4f16-b979-367cc54b789a\\peixes_category_1778427905433.png', products: [
        { titulo: 'Filé de Tilápia Fresco', descricao: 'Filé de tilápia limpo, pronto para grelhar ou fritar.', unidade: 'Kg', marca: 'Peixe Bom', preco: 45.00, estoque: 20, pedido_minimo: 1 },
        { titulo: 'Salmão Chileno Premium', descricao: 'Lombo de salmão fresco, rico em Ômega 3.', unidade: 'Kg', marca: 'Pacific', preco: 110.00, estoque: 10, pedido_minimo: 1 },
        { titulo: 'Camarão Cinza Limpo', descricao: 'Camarão cinza médio, descascado e limpo.', unidade: 'Pacote 500g', marca: 'Maré Alta', preco: 38.00, estoque: 30, pedido_minimo: 2 }
    ]},
    { id: 4, name: 'Bebidas', image: 'C:\\Users\\davib\\.gemini\\antigravity\\brain\\0688dd13-3cad-4f16-b979-367cc54b789a\\bebidas_category_1778427920767.png', products: [
        { titulo: 'Suco de Laranja Integral', descricao: 'Suco 100% fruta, sem adição de açúcar ou conservantes.', unidade: 'Garrafa 1L', marca: 'Prats', preco: 12.50, estoque: 60, pedido_minimo: 6 },
        { titulo: 'Cerveja Artesanal IPA', descricao: 'Cerveja encorpada com notas cítricas e amargor equilibrado.', unidade: 'Garrafa 500ml', marca: 'Colorado', preco: 18.90, estoque: 48, pedido_minimo: 12 },
        { titulo: 'Água Mineral sem Gás', descricao: 'Água mineral natural, fonte pureza.', unidade: 'Fardo 12x500ml', marca: 'Crystal', preco: 22.00, estoque: 100, pedido_minimo: 1 }
    ]},
    { id: 5, name: 'Limpeza', image: 'C:\\Users\\davib\\.gemini\\antigravity\\brain\\0688dd13-3cad-4f16-b979-367cc54b789a\\limpeza_category_1778427935170.png', products: [
        { titulo: 'Detergente Neutro 500ml', descricao: 'Detergente líquido para louças, alto poder desengordurante.', unidade: 'Unidade', marca: 'Ypê', preco: 2.50, estoque: 200, pedido_minimo: 24 },
        { titulo: 'Desinfetante Lavanda 2L', descricao: 'Limpa e perfuma todos os ambientes com fragrância de lavanda.', unidade: 'Garrafa', marca: 'Veja', preco: 14.90, estoque: 80, pedido_minimo: 4 },
        { titulo: 'Sabão em Pó OMO 1.6kg', descricao: 'Sabão em pó para roupas, lavagem perfeita.', unidade: 'Caixa', marca: 'OMO', preco: 21.00, estoque: 50, pedido_minimo: 2 }
    ]},
    { id: 6, name: 'Padaria', image: 'C:\\Users\\davib\\.gemini\\antigravity\\brain\\0688dd13-3cad-4f16-b979-367cc54b789a\\padaria_category_1778427947233.png', products: [
        { titulo: 'Pão Francês Tradicional', descricao: 'Pão francês fresquinho e crocante, entregue diariamente.', unidade: 'Kg', marca: 'Padaria Central', preco: 18.00, estoque: 100, pedido_minimo: 1 },
        { titulo: 'Croissant de Chocolate', descricao: 'Massa folhada amanteigada recheada com chocolate belga.', unidade: 'Unidade', marca: 'Le Pain', preco: 8.50, estoque: 40, pedido_minimo: 5 },
        { titulo: 'Bolo de Cenoura com Cobertura', descricao: 'Bolo caseiro de cenoura com generosa camada de chocolate.', unidade: 'Unidade', marca: 'Bolos da Vovó', preco: 25.00, estoque: 15, pedido_minimo: 1 }
    ]},
    { id: 7, name: 'Frutas', image: 'C:\\Users\\davib\\.gemini\\antigravity\\brain\\0688dd13-3cad-4f16-b979-367cc54b789a\\frutas_category_1778427961954.png', products: [
        { titulo: 'Banana Nanica Climatizada', descricao: 'Bananas doces e no ponto ideal para consumo.', unidade: 'Dúzia', marca: 'Doce Fruta', preco: 7.20, estoque: 80, pedido_minimo: 5 },
        { titulo: 'Maçã Gala Importada', descricao: 'Maçãs vermelhas, suculentas e crocantes.', unidade: 'Kg', marca: 'Apple Fresh', preco: 12.90, estoque: 60, pedido_minimo: 2 },
        { titulo: 'Manga Palmer Premium', descricao: 'Manga palmer sem fiapo, muito doce e carnuda.', unidade: 'Kg', marca: 'Frutas Nobres', preco: 9.50, estoque: 40, pedido_minimo: 3 }
    ]}
];

async function seed() {
    for (const cat of categories) {
        console.log(`Semeando categoria: ${cat.name}...`);
        
        let base64Image = '';
        try {
            const buffer = fs.readFileSync(cat.image);
            base64Image = `data:image/png;base64,${buffer.toString('base64')}`;
        } catch (err) {
            console.error(`Erro ao ler imagem da categoria ${cat.name}:`, err.message);
        }

        for (const prod of cat.products) {
            try {
                const [result] = await pool.query_mysql(
                    `INSERT INTO anuncios (
                        id_usuario, id_categoria, titulo, descricao, unidade, marca, 
                        pedido_minimo, regiao_atendida, prazo_entrega, formas_contato, 
                        status, preco_unitario, estoque, cidade, estado
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?) RETURNING id_anuncio`,
                    [
                        FORNECEDOR_ID, cat.id, prod.titulo, prod.descricao, prod.unidade, prod.marca,
                        prod.pedido_minimo, 'São Paulo e Grande SP', '24h - 48h', 'WhatsApp: (11) 88888-8888',
                        'ATIVO', prod.preco, prod.estoque, 'São Paulo', 'SP'
                    ]
                );

                const id_anuncio = result[0].id_anuncio;

                if (base64Image) {
                    await pool.query_mysql(
                        'INSERT INTO imagens_anuncio (id_anuncio, dados_imagem) VALUES (?, ?)',
                        [id_anuncio, base64Image]
                    );
                }

                console.log(`Produto criado: ${prod.titulo}`);
            } catch (err) {
                console.error(`Erro ao criar produto ${prod.titulo}:`, err.message);
            }
        }
    }
    console.log('Semeadura concluída!');
    process.exit();
}

seed();
