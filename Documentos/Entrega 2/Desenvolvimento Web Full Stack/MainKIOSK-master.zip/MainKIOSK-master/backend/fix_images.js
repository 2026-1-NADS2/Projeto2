import 'dotenv/config';
import { pool } from './src/db.js';

const imageMap = [
    { id: 28, title: 'Maçã', url: 'https://images.unsplash.com/photo-1560806887-1e4cd0b6bccb?w=600' },
    { id: 27, title: 'Banana', url: 'https://images.unsplash.com/photo-1603833665858-e61d17a86224?w=600' },
    { id: 18, title: 'Suco', url: 'https://images.unsplash.com/photo-1613478223719-2ab802602423?w=600' },
    { id: 21, title: 'Detergente', url: 'https://images.unsplash.com/photo-1584622650111-993a426fbf0a?w=600' },
    { id: 17, title: 'Camarão', url: 'https://images.unsplash.com/photo-1559737558-2f5a35f4520b?w=600' },
    { id: 22, title: 'Desinfetante', url: 'https://images.unsplash.com/photo-1584622781564-1d9876a13d00?w=600' },
    { id: 23, title: 'Sabão em pó', url: 'https://images.unsplash.com/photo-1576618148400-f54bed99fcfd?w=600' }
];

async function fixImages() {
    for (const item of imageMap) {
        try {
            // Remove imagens antigas
            await pool.query_mysql('DELETE FROM imagens_anuncio WHERE id_anuncio = ?', [item.id]);
            // Insere a nova URL de alta qualidade
            await pool.query_mysql(
                'INSERT INTO imagens_anuncio (id_anuncio, dados_imagem) VALUES (?, ?)',
                [item.id, item.url]
            );
            console.log(`✅ Imagem atualizada para: ${item.title} (ID: ${item.id})`);
        } catch (err) {
            console.error(`❌ Erro ao atualizar ${item.title}:`, err.message);
        }
    }
    console.log('--- Processo de correção de imagens concluído ---');
    process.exit();
}

fixImages();
