import 'dotenv/config';
import fs from 'fs';
import { pool } from './src/db.js';

const updates = [
    { id: 9, image: 'C:\\Users\\davib\\.gemini\\antigravity\\brain\\0688dd13-3cad-4f16-b979-367cc54b789a\\alface_crespa_1778429991763.png', isLocal: true },
    { id: 10, image: 'C:\\Users\\davib\\.gemini\\antigravity\\brain\\0688dd13-3cad-4f16-b979-367cc54b789a\\tomate_cereja_1778430005304.png', isLocal: true },
    { id: 11, image: 'C:\\Users\\davib\\.gemini\\antigravity\\brain\\0688dd13-3cad-4f16-b979-367cc54b789a\\cenoura_baby_1778430022351.png', isLocal: true },
    { id: 12, image: 'C:\\Users\\davib\\.gemini\\antigravity\\brain\\0688dd13-3cad-4f16-b979-367cc54b789a\\picanha_premium_1778430047284.png', isLocal: true },
    { id: 13, image: 'C:\\Users\\davib\\.gemini\\antigravity\\brain\\0688dd13-3cad-4f16-b979-367cc54b789a\\file_frango_swift_1778430060177.png', isLocal: true },
    { id: 14, image: 'C:\\Users\\davib\\.gemini\\antigravity\\brain\\0688dd13-3cad-4f16-b979-367cc54b789a\\costela_suina_bbq_1778430075180.png', isLocal: true },
    { id: 15, image: 'C:\\Users\\davib\\.gemini\\antigravity\\brain\\0688dd13-3cad-4f16-b979-367cc54b789a\\file_tilapia_1778430098472.png', isLocal: true },
    { id: 16, image: 'C:\\Users\\davib\\.gemini\\antigravity\\brain\\0688dd13-3cad-4f16-b979-367cc54b789a\\salmao_premium_1778430111097.png', isLocal: true },
    // URLs para os demais devido ao limite de cota de IA
    { id: 17, image: 'https://images.unsplash.com/photo-1559737558-2f5a35f4520b?auto=format&fit=crop&q=80&w=600', isLocal: false },
    { id: 18, image: 'https://images.unsplash.com/photo-1621506289937-4c721a938d86?auto=format&fit=crop&q=80&w=600', isLocal: false },
    { id: 19, image: 'https://images.unsplash.com/photo-1535958636474-b021ee887b13?auto=format&fit=crop&q=80&w=600', isLocal: false },
    { id: 20, image: 'https://images.unsplash.com/photo-1548839140-29a749e1cf4d?auto=format&fit=crop&q=80&w=600', isLocal: false },
    { id: 21, image: 'https://images.unsplash.com/photo-1584622781564-1d9876a13d00?auto=format&fit=crop&q=80&w=600', isLocal: false },
    { id: 22, image: 'https://images.unsplash.com/photo-1584622650111-993a426fbf0a?auto=format&fit=crop&q=80&w=600', isLocal: false },
    { id: 23, image: 'https://images.unsplash.com/photo-1558317374-067fb5f30001?auto=format&fit=crop&q=80&w=600', isLocal: false },
    { id: 24, image: 'https://images.unsplash.com/photo-1509440159596-0249088772ff?auto=format&fit=crop&q=80&w=600', isLocal: false },
    { id: 25, image: 'https://images.unsplash.com/photo-1555507036-ab1f4038808a?auto=format&fit=crop&q=80&w=600', isLocal: false },
    { id: 26, image: 'https://images.unsplash.com/photo-1576618148400-f54bed99fcfd?auto=format&fit=crop&q=80&w=600', isLocal: false },
    { id: 27, image: 'https://images.unsplash.com/photo-1571771894821-ad99026.17784?auto=format&fit=crop&q=80&w=600', isLocal: false },
    { id: 28, image: 'https://images.unsplash.com/photo-1560806887-1e4cd0b6bccb?auto=format&fit=crop&q=80&w=600', isLocal: false },
    { id: 29, image: 'https://images.unsplash.com/photo-1553279768-865429fa0078?auto=format&fit=crop&q=80&w=600', isLocal: false }
];

async function updateAll() {
    for (const item of updates) {
        let imageData = item.image;
        if (item.isLocal) {
            try {
                const buffer = fs.readFileSync(item.image);
                imageData = `data:image/png;base64,${buffer.toString('base64')}`;
            } catch (err) {
                console.error(`Erro ao ler arquivo ${item.image}:`, err.message);
                continue;
            }
        }

        try {
            // Primeiro removemos as imagens antigas para este anúncio para não duplicar
            await pool.query_mysql('DELETE FROM imagens_anuncio WHERE id_anuncio = ?', [item.id]);
            
            // Inserimos a nova imagem individual
            await pool.query_mysql(
                'INSERT INTO imagens_anuncio (id_anuncio, dados_imagem) VALUES (?, ?)',
                [item.id, imageData]
            );
            console.log(`Imagem atualizada para o anúncio ID: ${item.id}`);
        } catch (err) {
            console.error(`Erro ao atualizar anúncio ${item.id}:`, err.message);
        }
    }
    console.log('Todas as imagens individuais foram atualizadas!');
    process.exit();
}

updateAll();
