export type FAQItem = {
  id: string;
  question: string;
  answer: string;
};

export const faqData: FAQItem[] = [
  {
    id: 'cadastro',
    question: 'Como cadastrar um produto?',
    answer: 'Para cadastrar um produto, acesse sua conta como fornecedor e vá até o painel de anúncios. Clique em "Criar anúncio" e preencha as informações do produto.'
  },
  {
    id: 'contato',
    question: 'Como entrar em contato com fornecedores?',
    answer: 'Você pode entrar em contato com fornecedores diretamente pela página do anúncio, utilizando os dados fornecidos.'
  },
  {
    id: 'pagamento',
    question: 'Preciso pagar para usar a plataforma?',
    answer: 'A plataforma não realiza pagamentos. Ela funciona apenas como um canal de conexão entre compradores e fornecedores.'
  },
  {
    id: 'avaliacao',
    question: 'Como avaliar um fornecedor?',
    answer: 'Após visualizar um anúncio, você pode avaliá-lo com uma nota e comentário, desde que esteja logado.'
  },
  {
    id: 'senha',
    question: 'Esqueci minha senha, o que fazer?',
    answer: 'Na tela de login, clique em "Esqueci minha senha" para redefinir seu acesso.'
  },
  {
    id: 'ser_fornecedor',
    question: 'Como ser um fornecedor?',
    answer: 'Acesse o site e clique em "Seja um Fornecedor" e preencha o formulário com os dados da sua empresa.'
  },
  {
    id: 'ser_cnpj',
    question: 'Como alterar o CNPJ do fornecedor',
    answer: '.'
  }
];
